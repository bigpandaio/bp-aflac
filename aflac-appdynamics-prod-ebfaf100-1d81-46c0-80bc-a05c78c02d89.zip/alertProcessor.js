// load env variables for running locally
require('dotenv').config();

const fs = require('fs');

module.exports.handler = async (event, context) => {
  const packageJson = JSON.parse(fs.readFileSync('./package.json'));

  const winston = require('winston');
  const Logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    transports: [
      new winston.transports.Console()
    ],
    defaultMeta: {
      source: packageJson.name,
      version: packageJson.version,
      functionName: context.functionName,
      awsRequestId: context.awsRequestId,
      environment: process.env.NODE_ENV,
      organization: packageJson.customer
    }
  });

  Logger.log({
    level: 'info',
    message: 'New event:',
    event: event
  });

  const AlertRequest = require('./lib/alertRequest.js');
  const [response, alerts, error] = await AlertRequest.process(event, Logger);

  if (error) {
    Logger.log({
      level: 'error',
      message: `Error: ${response.body.message}`,
      errorMessage: error.message,
      stack: error.stack
    });
  }

  // log if each alert successfully processed from the event
  if (response.statusCode === 200) {
    Logger.log({
      level: 'info',
      message: 'Event Processed Successfully'
    });
  }

  return response;
};
