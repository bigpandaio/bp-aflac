// load env variables for running locally
require('dotenv').config();

const chai = require('chai');

const should = chai.should();
const DynamoTools = require('../lib/dynamotools.js');
const AWS = require('aws-sdk-mock');
const AWSSDK = require('aws-sdk');

describe('DynamoTools', () => {
    // restore any mocked AWS services
    beforeEach(() => {
        AWS.restore();
    });

    it('should initialize an internal DocumentClient', () => {
        const dynamo = new DynamoTools(process.env.AWS_REGION);
        should.exist(dynamo.docClient);
        dynamo.docClient.should.be.instanceof(AWSSDK.DynamoDB.DocumentClient);
    });

    it('should get an item from DynamoDB by table and primary key', async () => {
        AWS.mock('DynamoDB.DocumentClient', 'get', (params, callback) => {
            params.TableName.should.equal('testtable');
            params.Key.should.equal('testkey');
            callback(null, true);
        });

        const dynamo = new DynamoTools(process.env.AWS_REGION);
        await dynamo.getItem('testtable', 'testkey');
    });

    it('should get an item from DynamoDB by table and primary key', async () => {
        AWS.mock('DynamoDB.DocumentClient', 'delete', (params, callback) => {
            params.TableName.should.equal('testtable');
            params.Key.should.equal('testkey');
            callback(null, true);
        });

        const dynamo = new DynamoTools(process.env.AWS_REGION);
        await dynamo.deleteItem('testtable', 'testkey');
    });

    it('should put an item into a DynamoDB table', async () => {
        AWS.mock('DynamoDB.DocumentClient', 'put', (params, callback) => {
            params.TableName.should.equal('testtable');
            params.Item.foo.should.equal('bar');
            params.Item.baz.should.equal(1);
            callback(null, true);
        });

        const dynamo = new DynamoTools(process.env.AWS_REGION);
        await dynamo.putItem('testtable', {foo: 'bar', baz: 1});
    });

    it('should query a DynamoDB table for an item', async () => {
        AWS.mock('DynamoDB.DocumentClient', 'query', (params, callback) => {
            params.TableName.should.equal('testtable');
            params.KeyConditionExpression.should.equal('foo = :bar');
            params.ExpressionAttributeValues.bar.should.equal('baz');
            callback(null, true);
        });

        const dynamo = new DynamoTools(process.env.AWS_REGION);
        await dynamo.query('testtable', 'foo = :bar', {bar: 'baz'});
    });

    it('should optionally query a secondary index', async () => {
        AWS.mock('DynamoDB.DocumentClient', 'query', (params, callback) => {
            params.TableName.should.equal('testtable');
            params.KeyConditionExpression.should.equal('foo = :bar');
            params.ExpressionAttributeValues.bar.should.equal('baz');
            params.IndexName.should.equal('secondaryIndex');
            callback(null, true);
        });

        const dynamo = new DynamoTools(process.env.AWS_REGION);
        await dynamo.query('testtable', 'foo = :bar', {bar: 'baz'}, 'secondaryIndex');
    });

    it('should scan a table', async () => {
        AWS.mock('DynamoDB.DocumentClient', 'scan', (params, callback) => {
            params.TableName.should.equal('testtable');
            callback(null, true);
        });

        const dynamo = new DynamoTools(process.env.AWS_REGION);
        await dynamo.scan('testtable');
    });
});
