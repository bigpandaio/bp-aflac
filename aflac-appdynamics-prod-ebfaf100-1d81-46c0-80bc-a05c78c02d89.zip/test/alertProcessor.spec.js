// load env variables for running locally
require('dotenv').config();

const chai = require('chai');
const sinon = require('sinon');
const Logger = require('logzio-logger');
const AlertRequest = require('../lib/alertRequest.js');
const BigPanda = require('bigpanda');
const {handler} = require('../alertProcessor.js');

const should = chai.should(); // eslint-disable-line no-unused-vars

describe('Alert Processor', () => {
    const event = {};
    const properties = {
        incident_identifier: 1,
        primary_property: 'host',
        secondary_property: 'check',
        metric: 'metric',
        host: 'test',
        check: 'test'
    };
    const alertA = new BigPanda.Alert('1111111111111', 'critical', properties);
    const alertB = new BigPanda.Alert('appKey', 'critical', properties);
    const alerts = [alertA, alertB];
    const context = {
        functionName: 'functionNameValue',
        awsRequestId: 'awsRequestIdValue'
    };
    let logFake;
    let sendAndCloseFake;
    let processFake;

    before(() => {
        // stub out logger to prevent intentional errors getting logged
        logFake = sinon.replace(Logger, 'log', sinon.fake());

        // stub out sendAndClose
        const logzioWinstonTransport = Logger.transports.find((transport) => transport.name === 'winston_logzio');
        sendAndCloseFake = sinon.replace(logzioWinstonTransport.logzioLogger, 'sendAndClose', sinon.fake());

        processFake = sinon.replace(AlertRequest.prototype, 'process', sinon.fake(() =>
            [{message: 'hello, world', statusCode: 200}, alerts]));
    });

    after(() => {
        // remove all stubs
        sinon.restore();
    });

    beforeEach(() => {
        // reset fake histories
        logFake.resetHistory();
        sendAndCloseFake.resetHistory();
        processFake.resetHistory();
    });

    afterEach(() => {
    });

    it('should have AlertRequest process the event', async () => {
        await handler(event, context);

        processFake.callCount.should.equal(1);
    });

    it('should return the response from AlertRequest', async () => {
        // This returns whether the event was proccesed. It should not return alerts.
        const response = await handler(event, context);

        response.message.should.equal('hello, world');
    });

    it('should log the event when successfully processed', async () => {
        await handler(event, context);

        // One call for the pre-processed event and 2 for each alert
        logFake.callCount.should.equal(3);
    });

    it('should close out the logger before exiting', async () => {
        await handler(event, context);

        sendAndCloseFake.callCount.should.equal(1);
    });

    it('should log pre-proccessed event only if processing fails', async () => {
        // remove all stubs to make the event fail
        sinon.restore();

        // stub out logger to prevent intentional errors getting logged
        logFake = sinon.replace(Logger, 'log', sinon.fake());

        // stub out sendAndClose
        const logzioWinstonTransport = Logger.transports.find((transport) => transport.name === 'winston_logzio');
        sendAndCloseFake = sinon.replace(logzioWinstonTransport.logzioLogger, 'sendAndClose', sinon.fake());

        processFake = sinon.replace(AlertRequest.prototype, 'process', sinon.fake(() => [{
            message: 'hello, world',
            statusCode: 400
        }, alerts]));

        await handler(event, context);

        // One call for the pre-processed event
        logFake.callCount.should.equal(1);

        // One call for the logger close
        sendAndCloseFake.callCount.should.equal(1);
    });
});
