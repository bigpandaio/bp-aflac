// load env variables for running locally
require('dotenv').config();

const chai = require('chai');
const crypto = require('../lib/crypto-extra.js');

const should = chai.should(); // eslint-disable-line no-unused-vars

describe('Crypto Extra', () => {
    it('should hash a string', () => {
        const hash = crypto.hashString(Date.now().toString());
        hash.should.match(/^[a-fA-F0-9]{64}$/);
    });

    it('should support specifying an algorithm for string hashing', () => {
        const hash = crypto.hashString(Date.now().toString(), 'sha512');
        hash.should.match(/^[a-fA-F0-9]{128}$/);
    });

    it('should still provide default normal crypto functionality', () => {
        should.exist(crypto.createHmac);
        should.exist(crypto.randomBytes);
        should.exist(crypto.createPublicKey);
    });
});
