const request = require('request');
const Logger = require('logzio-logger');

const STATUS_MAP = {
    "unavailable": "critical",
    "error": "critical",
    "warning": "warning",
    "good": "ok"
};

// ---------------------------   MAIN FLOW     ---------------------------
exports.handler = (event, context, callback) => {

    Logger.setMeta('integration_type', 'custom_endpoint');
    Logger.setMeta('customer', 'aflac');
    Logger.setMeta('source', 'sitescope');
    Logger.setMeta('functionName', context.functionName);
    Logger.setMeta('awsRequestId', context.awsRequestId);
    Logger.setMeta('cloudwatchLink', `https://console.aws.amazon.com/cloudwatch/home?region=${process.env.AWS_REGION}#logEventViewer:group=${context.logGroupName};stream=${context.logStreamName};filter=%22${context.awsRequestId}%22`);

    console.log("Event: " + JSON.stringify(event, null, 2));
    console.log("Body: " + event.body);

    let alert = JSON.parse(event.body);

    // normalize

    alert['host'] = alert['Host'];
    alert['application'] = alert['Application'];

    delete alert['Host'];
    delete alert['Application'];

    alert['name'] = alert['Name'];
    delete alert['Name'];

    alert['status'] = STATUS_MAP[alert.Status];
    delete alert['Status'];

    alert['primary_property'] = 'host';
    alert['secondary_property'] = 'name';

    console.log("Alert: " + JSON.stringify(alert));

    forwardAlertsToBigPanda(alert, event, (errorMessage, result) => {
        let response = {};
        if (errorMessage) {
            console.log(errorMessage);
            Logger.log({
                level: 'error',
                message: `Failed to send alert.`,
                errorMessage: errorMessage,
                event: JSON.stringify(event),
                alert: JSON.stringify(alert),
            });
            Logger.sendAndClose();
            response.statusCode = 500;
            response.body = JSON.stringify({"message": errorMessage});
            response.headers = {'Cache-Control': 'no-cache'};
            callback(null, response);
        } else {
            // log if we successfully processed an event
            Logger.log({
                level: 'info',
                message: 'Alert sent successfully.',
                event: JSON.stringify(event),
                alert: JSON.stringify(alert),
            });
            // close out logger
            Logger.sendAndClose();
            console.log(result);
            response.statusCode = 200;
            response.body = JSON.stringify({"message": 'Success'});
            response.headers = {'Cache-Control': 'no-cache'};
            callback(null, response);
        }
    });
};

const forwardAlertsToBigPanda = (alerts, event, callback) => {
    console.log('Transmitting Alerts...');
    console.log(JSON.stringify(alerts));

    let encodedToken = event.headers.Authorization.replace("Basic ", "");
    encodedToken = Buffer.from(encodedToken, "base64");
    let decodedToken = encodedToken.toString("utf-8");
    decodedToken = decodedToken.replace(":", "");

    request({
        body: JSON.stringify(alerts),
        method: "POST",
        url: "https://api.bigpanda.io/data/v2/alerts",
        headers: {
            "Authorization": `Bearer ${decodedToken}`,
            "Content-Type": "application/json"
        },
    }, (error, response) => {
        if (error || response === undefined) {
            return callback("Error: Unable to connect to BigPanda API");
        }

        if (response.statusCode === 201) {
            return callback(undefined, "Success: BigPanda notified.");
        } else {
            return callback(`Error ${response.statusCode} ${response.statusMessage}: ${response.body}`);
        }
    });
};
