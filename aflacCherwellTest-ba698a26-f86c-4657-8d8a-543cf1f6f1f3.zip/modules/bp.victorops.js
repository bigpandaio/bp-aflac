
// Constants

var MAX_DESC_LENGTH = 32700;
var MAX_TITLE_LENGTH = 250;

var SYSTEM = 'VictorOps';
var DB_SYSTEM = SYSTEM;

var BP_HOST = "api.bigpanda.io";
var BP_HOST_LINK = "a.bigpanda.io";
var BP_BASE_PATH = "/resources/v1.0/incidents";

var PUSH_HOST_URL = "alert.victorops.com";
var PUSH_BASE_PATH = "/integrations/generic/20131114/alert";

var REQ_TIMEOUT = 7000;

var BASE_PUSH_REQ_OPS = {};
var BASE_BP_REQ_OPS = {};


var messageTypeMap = {
  'Critical': 'CRITICAL',
  'Warning': 'INFO',
  'Ok': 'RECOVERY'
}

// Init

// Modules
var bpUtils = require('./utils/bp-utils');

var AWS_REGION = "us-east-1";
var AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION });
AWS.config.setPromisesDependency(require('bluebird'));

var http = require('https');
var request = require('request');

// DynamoDB
var bpIncidentToTicketTable = null;
var docClient = new AWS.DynamoDB.DocumentClient();

// Localization

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
process.env.TZ = 'America/New_York';

function setupContext(context, incident, env, config, customerLogic, logicParams) {
  context.bpContext = {
    env: env,
    config: config,
    customerLogic: customerLogic,
    logicParams: logicParams
  };

  dbUniqueName = config.customer.name;

  if (config.customer.env) {
    dbUniqueName += "_" + config.customer.env;
  }

  bpIncidentToTicketTable = ("bp_" + dbUniqueName + "_" + DB_SYSTEM + "_incident_to_ticket").toLowerCase();

  config.BPHost = BP_HOST;
  config.BPHostLink = BP_HOST_LINK;

  if (getFlags(context).bpHostPrefix) {
    config.BPHost = getFlags(context).bpHostPrefix + "-" + BP_HOST;
    config.BPHostLink = getFlags(context).bpHostPrefix + "-" + BP_HOST_LINK;
  }

  // Keep the authToken only if requested to save it.
  // This should ONLY be used in the demo.
  // if this gets real, we can easily encrypt the token with our KMS key
  if (logicParams && logicParams.authToken) {
    console.log("Saving auth token");
    context.bpContext.overrideAuthToken = logicParams.authToken;
  }

  var routingKey = logicParams.routingKey || "";

  var pathParts = [
    PUSH_BASE_PATH,
    logicParams.apiKey,
    routingKey
  ]

  BASE_PUSH_REQ_OPS = {
    host: PUSH_HOST_URL,
    port: 443,
    path: pathParts.join("/"),
    agent: false,
    headers: {
        'Accept'      : 'application/json',
        'Content-Type': 'application/json'
    }
  };

  BASE_BP_REQ_OPS = {
      host: config.BPHost,
      port: 443,
      path: BP_BASE_PATH, // To be set dynamically with the incident Id.
      agent: false,
      headers: {
          'Content-Type': 'application/json'
      }
  };
}


// Formating customizatoins

function customizeTableRow(config, alertData, titleInfo, hasSubTitle, alertNum, totalAlerts) {
    var options = {year: "numeric", month: "short",day: "numeric"};
    var time = new Date(alertData.startedOn * 1000);

    time.setTime(time.getTime() + (time.getTimezoneOffset() + config.timezone.offset * 60) *60*1000); // Move to Current timezone
    var timeStr = time.toDateString("en-us", options) + " " + bpUtils.formatAMPM(time);

    var secondaryLine = hasSubTitle ? `\n${titleInfo.subTitleType}: ${alertData.secondary}` : '';
    var sourceStr = alertData.sourceSystem;

    return `Alert ${alertNum + 1} of ${totalAlerts} \n` +
           `Status: ${bpUtils.capitalizeFirstLetter(alertData.status)} \n` +
           `${titleInfo.titleType}: ${alertData.primary}${secondaryLine} \n` +
           `Description: ${(alertData.description || ' ')} \n` +
           `Started At: ${timeStr} \n` +
           `Source: ${alertData.sourceSystem} \n` +
           `------------------------------------------\n`;
}

function customizeTitle(config, incident, titleInfo) {
  var incidentTitle = titleInfo.title;
  var incidentSubtitle = titleInfo.subTitle;

  var title = incidentTitle + " - " + (incidentSubtitle ? ' / ' + incidentSubtitle : '');

  if (title.length >= MAX_TITLE_LENGTH - 3) {
    title = title.substring(0, MAX_TITLE_LENGTH - 3) + "...";
  }

  return title;
}


// ---------------------------    SYSTEM GENERIC    ---------------------------

function createRemoteLink(host, key) {
  return "https://portal.victorops.com";
}

// --------------------------- FLOW DECISIONS ---------------------------

// ---------------------------  GENERIC FORMATING    ---------------------------

function createFields(context, incident, action) {
    var titleInfo = createIncidentTitleInfo(incident);
    var config = getConfig(context);
    var customerLogic = getCustomerLogic(context);

    if (!titleInfo) {
        context.done(new Error("No alerts for incident: " + incident.id + " payload was: " + JSON.stringify(incident)));
        return;
    }

    var fields = {
        'entity_display_name': customizeTitle(config, incident, titleInfo),
        'state_message': formatDescription(config, incident, titleInfo),
        'state_start_time': incident.startedOn,
        'entity_id': incident.id,
        'message_type': messageTypeMap[incident.status]
    };

    additionalFieldsUpdate(context, config, incident, fields);

    if (customerLogic.customFieldsUpdate) {
      customerLogic.customFieldsUpdate(context, incident, fields);
    }

    return fields;
}

function additionalFieldsUpdate(context, config, incident, fields) {
  var logicParams = context.bpContext.logicParams;

  if (logicParams && logicParams.fields) {
    logicParams.fields.forEach(function(field) {
      fields[field.targetName] = bpUtils.getAlertTagsData(incident, field.sourceName);
    });
  }
}

function formatDescription(config, incident, titleInfo) {
  var infoText = formatInfoText(config, incident);
  var tableText = formatTable(config, incident, titleInfo, MAX_DESC_LENGTH - infoText.length);

  return tableText + '\n' + infoText;
}

function formatInfoText(config, incident) {
  var muted = (incident.snooze && incident.snooze.snoozed) ? '*Incident is snoozed in BigPanda*\n' : '';
  var source = '?bp_source=' + SYSTEM.toLowerCase();
  var message = null;    // Missing data
  var generatedBy = '';  // Missing data

  var incidentUrl = 'https://'+ config.BPHostLink + '/#/app/overview/all/search/incidents/' + incident.id;
  var bigpandaUrl = incidentUrl + source;
  var timelineUrl = incidentUrl + '/timeline' + source;

  var landingPageUrl = incident.links.landingPage;

  var links = '* Go to the [Incident Preview Page|'+landingPageUrl+']' +
      '\n* Investigate in the [BigPanda console|' + bigpandaUrl + ']' +
      '\n* See the [Incident Timeline|' + timelineUrl + ']';

  return (message ? (message + '\n') : '') + muted + generatedBy + links;
}

function formatTable(config, incident, titleInfo, maxTableLength) {
  var hasSubTitle = !!titleInfo.subTitleType;

  var table = "";
  var sortedAlerts = bpUtils.sortIncidentAlerts(incident.alerts);

  var alertsNum = incident.alerts.length;
  var tableLength = 0;
  var row = "";

  for (var i = 0; i < alertsNum; i++) {
    var alertData = formatAlertData(titleInfo, incident.alerts[i]);

    row = customizeTableRow(config, alertData, titleInfo, hasSubTitle, i, alertsNum);

    if ((table.length + row.length) >= maxTableLength) {
        table += `\n And ${alertsNum - i} more...`;
        break;
    }

    table += row;
    tableLength += row.length;
  }

  return table;
}

function createIncidentTitleInfo(incident) {
    if (!incident.alerts || incident.alerts.length === 0) {
      return null;
    }

    var incidentConfig = getIncidentConfig(incident);

    return {
        title: createTitleBasedOnProperty(incident, incidentConfig.primaryProperty),
        subTitle: createTitleBasedOnProperty(incident, incidentConfig.secondaryProperty),
        titleType: incidentConfig.primaryProperty,
        subTitleType: incidentConfig.secondaryProperty
    };
}

function formatAlertData(titleInfo, alertData) {
    alertData.primary = bpUtils.getAlertTagData(alertData, titleInfo.titleType);
    alertData.secondary = bpUtils.getAlertTagData(alertData, titleInfo.subTitleType);
    return alertData;
}

function createTitleBasedOnProperty(incident, property) {
    var propertyValues = [];

    incident.alerts.forEach(function (alert) {
        var tag = bpUtils.getAlertTagData(alert, property);
        propertyValues.push(tag);
    });

    propertyValues = bpUtils.uniqStrings(propertyValues);

    var title = propertyValues[0];

    if (propertyValues.length > 1) {
        title += " and " + (propertyValues.length - 1) + " more";
    }

    return title;
}



// --------------------------- GENERIC FLOW ---------------------------


// Main Flow

exports.handle = handle;

function handle(event, context, env, customerLogic, config, logicParams) {
    var incident = event.incident;
    incident.links = event.links; // Make it easier to access later on

    setupContext(context, incident, env, config, customerLogic, logicParams);

    // extractIssueKeyEvent(context, incident.id, function (issueKey) {
      createIssue(context, incident, customerLogic, onSuccess);
    // });

    function onSuccess(data) {
        console.log('Execution completed successfully.');

        if (data) {
            console.log(data);
        }

        context.succeed();
    }
}

function updateBigPandaIncident(context, incident, remoteKey, callback) {
    var env = getEnv(context);
    var systemEnv = env[SYSTEM.toLowerCase()];

    var host = env.internalHost || env.host;
    var issueLink = createRemoteLink(host, remoteKey);

    var reqOpts = bpUtils.createRequestOptions(BASE_BP_REQ_OPS, 'POST', '/' + incident.id);

    bpUtils.addRequestAuthToken(reqOpts, getAuthToken(context));

    var reqBody = {
        comments: SYSTEM + ' issue link: ' + issueLink
    };

    doApiCall(context, reqOpts, reqBody, SYSTEM, 'update BigPanda incident', 204, callback);
}


function createIssue(context, incident, customerLogic, callback) {
  console.log("Starting to create a new " + SYSTEM + " ticket for: " + incident.id);

  var reqOpts = bpUtils.createRequestOptions(BASE_PUSH_REQ_OPS, 'POST', '');

  var reqBody = createFields(context, incident, 'created');
  var config = getConfig(context);
  var env = getEnv(context);

  // var authToken = getAuthToken(context);

  doApiCall(context, reqOpts, reqBody, SYSTEM, 'creating issue', 200, function(data) {
      // storeIncidentKeyMapping(context, incident.id, data.key, authToken, function() {
          updateBigPandaIncident(context, incident, data.key, callback);
      // });
  });
}


// Generic API

function doApiCall(context, reqOpts, reqBody, service, happening, successCodes, onSuccess) {
  var config = getConfig(context);

  var maxTimeoutRetries = getAPIMaxTriesForAction(config, happening);
  var retries = 0;

  singleAPICall(context, retries, reqOpts, reqBody, service, happening, successCodes, onAPISuccess, onAPITimeout);

  function onAPISuccess(retryId, data) {
    if (retryId != retries) {
      console.log("Ignoring result - invalid retryId: " + retryId);
      return;
    }

    onSuccess(data);
  }

  function onAPITimeout() {
    if (retries >= maxTimeoutRetries) {
      context.done(new Error(happening + ' - timeout after retrying: ' + retries));
      return;
    }

    retries++;
    console.log(happening + " - (" + retries + ") retry after timout");

    return singleAPICall(context, retries, reqOpts, reqBody, service, happening, successCodes, onAPISuccess, onAPITimeout);
  }

}

function singleAPICall(context, retryId, reqOpts, reqBody, service, happening, successCodes, onSuccess, onTimeout) {
  var formatedRequest = JSON.stringify(reqBody);
  console.log("sending data to victorops", reqOpts);
  console.log(service + ' request body sent: ' + formatedRequest);

  var req = http.request(reqOpts, function (res) {
      var data = false;

      res.on('data', function (chunk) {
          // console.log(service + ' response body: ' + chunk);
          var success = false;
          data = true;

          if (successCodes.constructor !== Array) {
              successCodes = [successCodes];
          }

          successCodes.forEach(function(successCode) {
              if (res.statusCode == successCode) {
                  success = true;
              }
          });

          if (success) {
              console.log(new String(chunk));

              // TODO - Validate Json
              onSuccess(retryId, JSON.parse(chunk));
          } else {
              console.log('Error res: ' + new String(chunk));
              context.done(new Error(happening + ' failed with: ' + res.statusCode));
          }
      });

      res.on('end', function() {
          if (!data) {
              onSuccess(retryId); // No data
          }
      });
  });

  req.write(formatedRequest);
  req.end();

  req.on('error', function (err) {
      context.done(new Error(service + ' request error: ' + err.message));
  });
  req.setTimeout(REQ_TIMEOUT, onTimeout);
}

function getAPIMaxTriesForAction(config, action) {
  // don't allow any retries on incident creation - having a retry might
  // cause multiple tickets.
  if (action === 'creating issue') {
    return 0;
  }

  return 2;
}

// DB Store

function storeIncidentKeyMapping(context, incidentId, key, authToken, callback) {

  var mapping = {
      outbound_system: DB_SYSTEM,
      incident_id: incidentId,
      ticket_key: key,
      timestamp: new Date().getTime()
  };

  var config = getConfig(context);

  if (getFlags(context).saveAuthToken) {
    mapping.auth_token = authToken;
  }

  var params = {
    TableName: bpIncidentToTicketTable,
    Item: mapping
  };

  console.log("Adding a new item...");

  docClient.put(params,
    function(err, data) {
      if (err) {
      console.error("Unable to add Incident => Issue Mapping . Error JSON:", JSON.stringify(err, null, 2));
      } else {
        console.log("Added Incident => Issue Mapping", mapping);
        callback(data);
      }
    });
}

function extractIssueKeyEvent(context, incidentId, callback) {
  var params = {
    TableName: bpIncidentToTicketTable,
    Key: {
      outbound_system: DB_SYSTEM,
      incident_id: incidentId,
    }
  };

  docClient.get(params, function(err, data) {
    if (err) {
      console.log('Error in get issue key by incident' + JSON.stringify(err, null, 2));
    } else {
      console.log(JSON.stringify(data, null, 2));
      if (!!data.Item) {
        callback(data.Item.ticket_key);
      } else {
        callback(null);
      }
    }
  });
}

function getIncidentConfig(incident) {
    var alert = incident.alerts[0];

    // Heck to overcome how nagios primary properties are getting sent.
    if (alert.sourceSystem.startsWith("nagios") ||
        alert.sourceSystem.startsWith("icinga")) {
        return {
            primaryProperty: "_host",
            secondaryProperty: "_check"
        }
    }

    return {
        primaryProperty: alert.primaryProperty,
        secondaryProperty: alert.secondaryProperty
    }
}


function getConfig(context) {
  return context.bpContext.config;
}

function getEnv(context) {
  return context.bpContext.env;
}

function getCustomerLogic(context) {
  return context.bpContext.customerLogic;
}

function getAuthToken(context) {
  return context.bpContext.overrideAuthToken || getEnv(context).bp.authToken;
}

function getFlags(context) {
  return getConfig(context).flags || {}
}
