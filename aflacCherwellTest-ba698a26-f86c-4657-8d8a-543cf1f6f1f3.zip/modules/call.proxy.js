

// --------------------------- GENERIC CODE ---------------------------

// Constants

const SYSTEM = 'proxy';
const CUSTOM_FIELD_PREFIX = "x-bp-field-";
const CUSTOM_CONFIG_PREFIX = "x-bp-config-";
const CUSTOM_HEADER_PREFIX = "x-bp-header-";

// Init

// Modules
var bpUtils = require('./utils/bp-utils');
var _ = require('underscore');

function setupContext(context, env, config) {
  context.bpContext = {
    env: env,
    config: config
  };
}

// Main Flow

// Available config
// url
// onUpdate (default to false)

exports.handle = (event, context, env, config, callback) => {
    setupContext(context, env, config);

    const incident = event.body.incident;
    let requestParams = {};

    if (event.params && event.params.header) {
      requestParams.fields = [];

      _.keys(event.params.header).forEach(function(header) {
        var fieldStart = header.indexOf(CUSTOM_FIELD_PREFIX);
        var configStart = header.indexOf(CUSTOM_CONFIG_PREFIX);
        var headerStart = header.indexOf(CUSTOM_HEADER_PREFIX);

        let fieldValue = event.params.header[header];

        if (fieldStart == 0 && fieldValue) {
          requestParams.fields.push({
            sourceName: header.substring(fieldStart + CUSTOM_FIELD_PREFIX.length),
            targetName: fieldValue
          });
        }

        if (configStart == 0 && event.params.header[header]) {
          let configField = header.substring(CUSTOM_CONFIG_PREFIX.length);
          config[configField] = fieldValue
        }

        if (headerStart == 0 && fieldValue) {
          if (!config.headers) { config.headers = {}; }
          let headerField = header.substring(CUSTOM_HEADER_PREFIX.length);
          config.headers[headerField] = fieldValue
        }
      });
    }

    let metadata = {};

    if (event.body.metadata) {
      metadata = bpUtils.extractMetadata(event.body.metadata);

      console.log("Setting metadata for incident", metadata);
    }

    bpUtils.extractIssueKeyEvent(context, SYSTEM, incident.id, (err, storedMapping) => {
      if (err) {
        return finished(err);
      }

      console.log(storedMapping);
      if (metadata.autoShared) {
        finished(err, "Auto Share / Update - ignore");

      } else if (!storedMapping || config.onUpdate) {
          pushEvent(context, event.body, config, (err, data) => {
            if (err) {
              return finished(err);
            }

            bpUtils.storeIncidentKeyMapping(context, SYSTEM, incident.id, true, null, (err, storedData) => {
              return finished(err, data); // Returning the original data returned by the pushEvent
            });
          })
      } else {
        finished(err, "Incident already sent");
      }
    });

    function finished(err, data) {
      if (err) {
        console.log("returning error: " + err);
        return callback(JSON.stringify({status: 400, error: err + ""}));
      }

      console.log('Execution completed successfully.');

      if (data) {
          console.log(data);
      }

      callback(null, data);
    }
}

function pushEvent(context, eventBody, config, callback) {
  let opts = {
    host: config.host,
    port: config.port || 443,
    path: config.path,
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  };

  if (config.headers) { Object.assign(opts.headers, config.headers); }

  console.log("Pushing event to", opts);

  bpUtils.doApiCall(context,
                    opts,
                    eventBody,
                    SYSTEM,
                    'posting issue',
                    [200, 201, 204],
                    callback);
}
