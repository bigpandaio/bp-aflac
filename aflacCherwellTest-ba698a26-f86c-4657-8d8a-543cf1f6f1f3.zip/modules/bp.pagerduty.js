const request = require('request');
const bpUtils = require('modules/utils/bp-utils');
const bpFormatUtils = require('modules/utils/bp-format-utils');

const PD_EVENTS_ENDPOINT = 'https://events.pagerduty.com/v2/enqueue';
const SYSTEM = 'PagerDuty';

const SEVERITY_MAPPING = {
  Warning: 'warning',
  Critical: 'critical',
  Unknown: 'info'
}

function submitIncident(incident, config) {
  return new Promise((resolve, reject) => {
    const links = bpUtils.createLinks('a.bigpanda.io', SYSTEM, incident, config.metadata);
    let alertCustomDetails = additionalFieldsUpdate(config, incident);
    let integrationKey = config.pagerduty.token;

    if (config.pagerduty.key_field) {
      let tmpKey = bpUtils.getAlertTagsData(incident, config.pagerduty.key_field);
      if (typeof tmpKey === 'string') { integrationKey = tmpKey.split(',')[0]; }
    }

    const requestBody = {
      "payload": {
        "summary": bpFormatUtils.customizeTitle(config, incident, 256, bpFormatUtils.createIncidentTitleInfo(incident)), // incident title
        "source": "BigPanda", // incident primary value
        "severity": SEVERITY_MAPPING[incident.severity] || 'info' , // warning|critical
        "custom_details": alertCustomDetails
      },
      "routing_key": integrationKey,
      "dedup_key": incident.id,
      "links": [{
        "href": links.landingPageUrl,
        "text": "BigPanda Preview"
      },{
        "href": links.incidentUrl,
        "text": "BigPanda Incident"
      },{
      	"href": links.timelineUrl,
      	"text": "BigPanda Timeline"
      }],
      "event_action": (incident.status === 'Ok') ? 'resolve' : 'trigger'
    };

    console.log('Creating PagerDuty Ticket:');
    console.log(JSON.stringify(requestBody));
    request.post({
      headers: { 'Content-Type': 'application/json' },
      url: PD_EVENTS_ENDPOINT,
      body: JSON.stringify(requestBody),
    }, function(err, response, resBody) {
      if (err) { reject(err); }
      else if (response.statusCode === 202 && JSON.parse(resBody).status === 'success') {
        console.log('PagerDuty Ticket created:');
        console.log(resBody);
        resolve(true);
      } else {
        console.log('Failed to create PagerDuty Ticket:');
        console.log('Status ' + response.statusCode);
        console.log(resBody);
        reject('Invalid Request');
      }
    });
  });
}

function additionalFieldsUpdate(config, incident) {
  let fields = {};
  var logicParams = config.custom_pagerduty_fields;

  if (logicParams) {
    logicParams.forEach(function(field) {
      fields[field.targetName] = bpUtils.getAlertTagsData(incident, field.sourceName);
    });
  }

  fields.description = bpFormatUtils.createIncidentDescription(config, incident);

  return fields;
}

function trigger(event, config) {
  return new Promise((resolve, reject) => {
    const incidentId = event.log_entries[0].channel.cef_details.dedup_key;
    const link = event.incident.html_url;
    const assignee = event.incident.assignments[0].assignee.summary;
    const escalation = event.incident.escalation_policy.summary;
    const service = event.incident.service.name;
    const ticketId = event.incident.id;
    const linkComment = 'PagerDuty Ticket created: ' + link;
    const detailComment = `PagerDuty Ticket Assigned to ${assignee} in Service: ${service} - via Escalation Policy: ${escalation}`;

    bpUtils.storeDynamoData(config.dynamoTable, {
      org_token: config.customer.token,
      pd_ticket: ticketId,
      bp_incident: incidentId
    }, (err, data) => {
      if (err) { reject(err); }
      else {
        updateBigPanda(ticketId, detailComment, config)
        updateBigPanda(ticketId, linkComment, config)
        .then(() => resolve(true))
        .catch(err => reject(err));
      }
    });
  });
}

function action(event, config) {
  const ticketId = event.incident.id;
  const comment = 'PagerDuty Ticket ' + event.log_entries[0].summary;

  return updateBigPanda(ticketId, comment, config);
}

function resolve(event, config) {
  const ticketId = event.incident.id;
  const comment = 'PagerDuty Ticket ' + event.log_entries[0].summary;

  event.resolveTicket = true;
  return updateBigPanda(ticketId, comment, config, true);
}

function annotate(event, config) {
  const ticketId = event.incident.id;
  let comment = 'PagerDuty ' + event.log_entries[0].summary + ': ' + event.log_entries[0].channel.summary;

  if (event.log_entries[0].channel.summary.startsWith('Resolution Note: ')) {
    comment = 'PagerDuty Resolution ' + event.log_entries[0].summary + ': ' + event.log_entries[0].channel.summary.substring(17);
  }

  return updateBigPanda(ticketId, comment, config);
}

function updateBigPanda(ticketId, comment, config, resolveIncident) {
  return new Promise((resolve, reject) => {
    bpUtils.getDynamoData(config.dynamoTable, {
      org_token: config.customer.token,
      pd_ticket: ticketId
    }, (err, data) => {
      if (err) { reject(err); }
      else if (!data) { reject('Incident Id Not Found'); }
      else{
        console.log('Submitting comment to ' + data.bp_incident + ':');
        console.log(comment);

        let requestBody = '{ "comments": "' + comment + '" }';

        if (resolveIncident) {
          requestBody = '{ "resolved" : true, "comments": "' + comment + '" }';
        }

        request.post({
          auth: { 'bearer': config.customer.token },
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json'
          },
          url: 'https://api.bigpanda.io/resources/v1.0/incidents/' + data.bp_incident,
          body: requestBody
        }, (err, response, resBody) => {
          if (err) {
            console.log('Unable to submit incident comment:');
            console.log(err);
          } else {
            console.log('Comment Submitted');
          }
          resolve(true);
        });
      }
    });
  });
}

function detectType(event) {
  if (event.status) {
    return 'incident';
  } else if (event.event && event.event.startsWith('incident.')) {
     return event.event.substring(9)
  } else {
    return 'invalid';
  }
}

exports.handler = (events, config, callback) => {
  let promiseArray = [];

  events.forEach(event => {
    switch (detectType(event)) {
      case 'incident':
        promiseArray.push(submitIncident(event, config));
        break;
      case 'trigger':
        promiseArray.push(trigger(event, config));
        break;
      case 'resolve':
        promiseArray.push(resolve(event, config));
        break;
      case 'annotate':
        promiseArray.push(annotate(event, config));
        break;
      default:
        promiseArray.push(action(event, config));
    }
  });

  Promise.all(promiseArray)
  .then(() => callback(null, {statusCode: 200}))
  .catch(err => {
    console.log('Error:');
    console.log(err)
    callback(null, {statusCode: 200})
  });
};
