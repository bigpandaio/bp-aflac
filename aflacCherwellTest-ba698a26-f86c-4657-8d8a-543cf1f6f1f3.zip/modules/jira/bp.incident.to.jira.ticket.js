/// Open Items:
// 1. Better title?
// 2. source system at the moment is the uid and not the display name - good for now, in the worst case we can create a map
// 3. Comments or some note on what changed (created, updated, reopend...) - need to see if this is needed
// 4. support for cross source correlation?? [FUTURE]


// Constants

var MAX_DESC_LENGTH = 32700;
var MAX_TITLE_LENGTH = 250;

var SYSTEM = 'JIRA';
var DB_SYSTEM = SYSTEM;

var JIRA_PORT = 443;

var BP_HOST = "api.bigpanda.io";
var BP_HOST_LINK = "a.bigpanda.io";
var BP_BASE_PATH = "/resources/v1.0/incidents";

var REQ_TIMEOUT = 7000;


// Init

// Modules
var bpUtils = require('../utils/bp-utils');

var flowLogicSQS = require('./bp.incident.to.jira.sqs.flow.logic');
var flowLogicAPI = require('./bp.incident.to.jira.api.flow.logic');


var AWS_REGION = "us-east-1";
var AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION });
AWS.config.setPromisesDependency(require('bluebird'));


var http = require('https');
var request = require('request');

// DynamoDB
var bpIncidentToTicketTable = null;
var docClient = new AWS.DynamoDB.DocumentClient();

// Localization

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
process.env.TZ = 'America/New_York';

function setupContext(context, incident, env, config, customerLogic, logicParams) {

  context.bpContext = {
    env: env,
    config: config,
    customerLogic: customerLogic,
    system: SYSTEM,
    flowLogic: createFlowLogic(env, customerLogic, config),
  };

  // Backwards competability of switching JIRA config to config
  if (!config.jira) {
    config.jira = env.jira;
  }

  dbUniqueName = config.customer.name;

  if (config.customer.env) {
    dbUniqueName += "_" + config.customer.env;
  }

  bpIncidentToTicketTable = ("bp_" + dbUniqueName + "_" + DB_SYSTEM + "_incident_to_ticket").toLowerCase();

  config.BPHost = BP_HOST;
  config.BPHostLink = BP_HOST_LINK;

  if (getFlags(context).bpHostPrefix) {
    config.BPHost = getFlags(context).bpHostPrefix + "-" + BP_HOST;
    config.BPHostLink = getFlags(context).bpHostPrefix + "-" + BP_HOST_LINK;
  }

  if (getFlags(context).bpDynamicHostPrefix) {
    var foundEnv = incident.links.landingPage.match(/http:\/\/([a-z0-9]+)\.bigp/);
    config.BPEnv = foundEnv[1];

    if (foundEnv) {
      config.BPHost = config.BPEnv + "-" + BP_HOST;
      config.BPHostLink = config.BPEnv + "-" + BP_HOST_LINK;
    }
  }

  // Might be better to move this somewhere else
  if (customerLogic.createProjectKey) {
    var projectKey = customerLogic.createProjectKey(context, incident);

    if (projectKey) {
      // Override the project key with a specific one
      // Env is behind read from file every exeuction so no concerns here.
      config.jira.projectKey = projectKey;
    }
  }

  if (customerLogic.createIssueType) {
    var issueType = customerLogic.createIssueType(context, incident);

    if (issueType) {
      // Override the issueType with a specific one
      // Env is behind read from file every exeuction so no concerns here.
      config.jira.issueType = issueType;
    }
  }

  // Keep the authToken only if requested to save it.
  // This should ONLY be used in the demo.
  // if this gets real, we can easily encrypt the token with our KMS key
  if (logicParams && logicParams.authToken && getFlags(context).saveAuthToken) {
    console.log("Saving auth token");
    context.bpContext.overrideAuthToken = logicParams.authToken;
  }


  context.bpContext.flowLogic.setupContext(context,
                                           incident,
                                           env,
                                           config,
                                           customerLogic,
                                           logicParams);

  return;

  function createFlowLogic(env, customerLogic, config) {
    console.log(config)
    if (config.flowLogic && config.flowLogic.type == "SQS") {
      return flowLogicSQS;
    } else {
      return flowLogicAPI;
    }
  }
}

// Formating customizatoins

function customizeTableHeader(config, titleInfo, hasSubTitle) {
    return '||' + bpUtils.capitalizeFirstLetter(titleInfo.titleType) +
            (hasSubTitle ?  '||' + bpUtils.capitalizeFirstLetter(titleInfo.subTitleType) : '') +
            '||Status||Started at (' + config.timezone.name + ')||Description||Source System||\n';
}

function customizeTableRow(config, alertData, hasSubTitle) {
    var options = {year: "numeric", month: "short",day: "numeric"};
    var time = new Date(alertData.startedOn * 1000);

    time.setTime(time.getTime() + (time.getTimezoneOffset() + config.timezone.offset * 60) *60*1000) // Move to Current timezone
    var timeStr = time.toDateString("en-us", options) + " " + bpUtils.formatAMPM(time);

    if (alertData.description) {
      alertData.description = alertData.description.replace(/\|/g, "\\|").replace(/\n+/g, '\n');
    }

    return `|${alertData.primary}${hasSubTitle ? '|' + alertData.secondary : ''}|${alertData.status}|${timeStr}|${(alertData.description || ' ')}|${alertData.sourceSystem}|\n`;
}

function customizeTitle(config, incident, titleInfo) {
  var jiraTitle = '[BigPanda] ';

  var incidentTitle = titleInfo.title;
  var incidentSubtitle = titleInfo.subTitle

  jiraTitle += 'Incident ' + incidentTitle + (incidentSubtitle ? ' / ' + incidentSubtitle : '');

  if (jiraTitle.length >= MAX_TITLE_LENGTH - 3) {
    jiraTitle = jiraTitle.substring(0, MAX_TITLE_LENGTH - 3) + "...";
  }

  return jiraTitle;
}

// ---------------------------  GENERIC FORMATING    ---------------------------

function createJiraFields(context, incident, action) {
    var customerLogic = getCustomerLogic(context);
    var config = bpUtils.getConfig(context);
    var titleInfo = createIncidentTitleInfo(incident, customerLogic);

    if (!titleInfo) {
        context.done(new Error("No alerts for incident: " + incident.id + " payload was: " + JSON.stringify(incident)));
        return;
    }

    var fields = {
        'summary': customizeTitle(config, incident, titleInfo),
        'description': formatDescription(config, incident, titleInfo, customerLogic)
    };

    if (config.fieldMapping && config.fieldMapping.incident) {
      fields[config.fieldMapping.incident.id] = incident.id;
    }

    additionalFieldsUpdate(config, incident, fields);

    if (customerLogic.customFieldsUpdate) {
      customerLogic.customFieldsUpdate(context, incident, fields);
    }

    return fields;
}

function additionalFieldsUpdate(config, incident, fields) {
    var fieldMapping = config.fieldMapping;

    if (!fieldMapping) {
      return;
    }

    if (fieldMapping.status) {
        fields[fieldMapping.status] = { id: incident.status };
    }

    if (fieldMapping.priority) {
        var config = fieldMapping.priority;

        extractPriority(incident, fields, config);
    }

    if (fieldMapping.alert) {
        for (var prop in fieldMapping.alert) {
            // skip loop if the property is from prototype
            if (!fieldMapping.alert.hasOwnProperty(prop)) continue;

            fields[fieldMapping.alert[prop]] = bpUtils.getAlertTagsData(incident, prop);
            console.log("Adding :" + bpUtils.getAlertTagsData(incident, prop) + " to " + prop);
        }
    }
}

function extractPriority(incident, fields, config) {
    var priorityId = null;

    if (config.mapping &&
        config.mapping.alertField &&
        config.mapping.priorityOrder) {

        var priority = bpUtils.getAlertTagsData(incident, config.mapping.alertField, !config.mapping.includeResolved) || config.mapping.defaultPriority; // Only get active Alerts

        if (priority) {
            console.log("alerts priority tag is: " + priority);
            config.mapping.priorityOrder.forEach(function(po) {
                if (priorityId == null && priority.indexOf(po.value) >= 0) {
                    console.log("setting priorityId: " + po.id);
                    priorityId = po.id;
                }
            })
        }
    }

    if (priorityId == null && config.status && incident.status) {
        console.log("Setting status: " + config.status + " for: " + incident.status.toLowerCase());
        priorityId = config.status[incident.status.toLowerCase()];
    }

    if (priorityId) {
        fields.priority = {id: priorityId};
    }
}

function formatDescription(config, incident, titleInfo, customerLogic) {
  var infoText = formatInfoText(config, incident);
  var tableText = formatTable(config, incident, titleInfo, MAX_DESC_LENGTH - infoText.length, customerLogic);

  return tableText + '\n' + infoText;
}

function formatInfoText(config, incident) {
  var muted = (incident.snooze && incident.snooze.snoozed) ? '*Incident is snoozed in BigPanda*\n' : '';
  var message = null;    // Missing data
  var generatedBy = '';  // Missing data

  var links = bpUtils.createLinks(config.BPHostLink, SYSTEM, incident, config.metadata);

  var linksStr = '';

  if (config.flow && config.flow.showEnvironment && config.metadata && config.metadata.environment) {
    linksStr += 'Ticket was automatically shared after matching environment "' + config.metadata.environment + '"\n';
  }
  
  if (!config.flow.suppressPreviewLink){
    linksStr += '* Go to the ' + bpUtils.formatLink('Incident Preview Page', links.landingPageUrl, "markdown") + '\n';
  }

  linksStr += '* Investigate in the ' + bpUtils.formatLink('BigPanda console', links.incidentUrl, "markdown") +
              '\n* See the ' + bpUtils.formatLink('Incident Timeline', links.timelineUrl, "markdown");

  return (message ? (message + '\n') : '') + muted + generatedBy + linksStr;
}

function formatTable(config, incident, titleInfo, maxTableLength, customerLogic) {
  var hasSubTitle = !!titleInfo.subTitleType;

  var table = customizeTableHeader(config, titleInfo, hasSubTitle);

  var sortedAlerts = bpUtils.sortIncidentAlerts(incident.alerts);

  var alertsNum = incident.alerts.length;
  var tableLength = 0;
  var row = "";

  for (var i = 0; i < alertsNum; i++) {
    var alertData = formatAlertData(titleInfo, incident.alerts[i], customerLogic);

    row = customizeTableRow(config, alertData, hasSubTitle);

    if ((table.length + row.length) >= maxTableLength) {
        table += `\n And ${alertsNum - i} more...`;
        break;
    }

    table += row;
    tableLength += row.length;
  }

  return table;
}

/**
 * title info:
 *  title:
 *  subtitle (if exists)
 */
function createIncidentTitleInfo(incident, customerLogic) {
    if (!incident.alerts || incident.alerts.length === 0) {
      return null;
    }

    var incidentConfig = getIncidentConfig(incident);

    var titleInfo = {
        title: createTitleBasedOnProperty(incident, incidentConfig.primaryProperty),
        subTitle: createTitleBasedOnProperty(incident, incidentConfig.secondaryProperty),
        titleType: incidentConfig.primaryProperty,
        subTitleType: incidentConfig.secondaryProperty
    }

    if (customerLogic.createIncidentTitleInfo) {
       customerLogic.createIncidentTitleInfo(incident, titleInfo);
    }

    return titleInfo;
}

function formatAlertData(titleInfo, alertData, customerLogic) {
    alertData.primary = bpUtils.getAlertTagData(alertData, titleInfo.titleType);
    alertData.secondary = bpUtils.getAlertTagData(alertData, titleInfo.subTitleType);

    if (customerLogic.formatAlertData) {
      customerLogic.formatAlertData(titleInfo, alertData);
    }

    return alertData;
}

function createTitleBasedOnProperty(incident, property) {
    var propertyValues = [];

    incident.alerts.forEach(function (alert) {
        var tag = bpUtils.getAlertTagData(alert, property);
        propertyValues.push(tag);
    });

    propertyValues = bpUtils.uniqStrings(propertyValues);

    var title = propertyValues[0];

    if (propertyValues.length > 1) {
        title += " and " + (propertyValues.length - 1) + " more";
    }

    return title;
}



// --------------------------- GENERIC FLOW ---------------------------
// Main Flow

exports.handle = handle;

function handle(event, context, env, customerLogic, config, logicParams, callback) {
  try {
      var incident = event.incident;
      incident.links = event.links; // Make it easier to access later on

      setupContext(context, incident, env, config, customerLogic, logicParams);

      extractJiraIssueKeyEvent(context, incident.id, function (jiraIssueKey) {
          if (!!jiraIssueKey) {
              updateJiraIssue(context, incident, jiraIssueKey, customerLogic, finished);
          } else {
              createJiraIssue(context, incident, customerLogic, finished);
          }
      });
    } catch (err) {
      finished(err);
    }

    function finished(err, data) {
      if (err) {
        console.log("returning error: " + err);
        return callback(JSON.stringify({status: 400, error: err + ""}));
      }

      console.log('Execution completed successfully.');

      if (data) { console.log(data); }
      else { data = {}; }
      data.statusCode = 200;

      callback(null, data);
    }
}

// Jira Operations

function updateJiraIssue(context, incident, key, customerLogic, callback) {
    console.log("Starting to update a new jira ticket for: " + incident.id);
    var config = bpUtils.getConfig(context);

    var fields = createJiraFields(context, incident, 'updated');

    if (customerLogic.customUpdateFields) {
      customerLogic.customUpdateFields(context, incident, fields);
    }

    context.bpContext.flowLogic.updateIssue(context, incident, key, fields, callback);
}

function createJiraIssue(context, incident, customerLogic, callback) {
  console.log("Starting to create a new jira ticket for: " + incident.id);


  var fields = createJiraFields(context, incident, 'created');
  var config = bpUtils.getConfig(context);
  var env = getEnv(context);


  fields.project = {'key': config.jira.projectKey};
  fields.issuetype = {'name': config.jira.issueType};

  if (customerLogic.customOnCreateFields) {
    customerLogic.customOnCreateFields(context, incident, fields);
  }
  console.log("config=flowLogic==" + JSON.stringify(config));
  context.bpContext.flowLogic.createIssue(context, fields, incident, callback);

}

function extractJiraIssueKeyEvent(context, incidentId, callback) {
  var params = {
    TableName: bpIncidentToTicketTable,
    Key: {
      outbound_system: context.primaryKey || DB_SYSTEM,
      incident_id: incidentId,
    }
  };

  docClient.get(params, function(err, data) {
    if (err) {
      console.log('Error in get issue key by incident' + JSON.stringify(err, null, 2));
    } else {

      console.log(JSON.stringify(data, null, 2));
      if (!!data.Item) {

        callback(data.Item.ticket_key);
      } else {

        callback(null);
      }
    }
  });
}


function getIncidentConfig(incident) {
    var alert = incident.alerts[0];

    // Heck to overcome how nagios primary properties are getting sent.
    if (alert.sourceSystem.startsWith("nagios") ||
        alert.sourceSystem.startsWith("icinga")) {
        return {
            primaryProperty: "_host",
            secondaryProperty: "_check"
        }
    }

    return {
        primaryProperty: alert.primaryProperty,
        secondaryProperty: alert.secondaryProperty
    }
}

// function getConfig(context) {
//   return context.bpContext.config;
// }

function getEnv(context) {
  return context.bpContext.env;
}

function getAuthToken(context) {
  return context.bpContext.overrideAuthToken || getEnv(context).bp.authToken;
}

function getFlags(context) {
  return bpUtils.getConfig(context).flags || {}
}

function getCustomerLogic(context) {
  return context.bpContext.customerLogic;
}
