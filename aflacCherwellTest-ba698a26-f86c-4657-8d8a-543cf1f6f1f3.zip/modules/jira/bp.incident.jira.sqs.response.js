var bpUtils = require('../utils/bp-utils');
var AWS_REGION = "us-east-1";
var AWS = require('aws-sdk');
var SQS = new AWS.SQS({region : 'us-east-1'});

exports.handle = handle;

function handle(event, context, env, CONFIG, callback){
  setupContext(context, env, CONFIG)
  console.log('Received following message payload from jira')
  console.log(event)

  // Auth token should be taken from the env.
  var authToken = getAuthToken(env);
  var queueName = CONFIG.sqs.queueName;
  var incidentId = event.bp_incident_id;
  var jiraKey = event.body.key;
  var errors = event.body.error;
  var SYSTEM = 'JIRA';
  var issueLink = "";


  if (!incidentId) {
    ackMessage();

  } else {
        bpUtils.storeIncidentKeyMapping(context, SYSTEM, incidentId, jiraKey, authToken, function() {
        if (errors != null && errors != '') {
          issueLink = 'Error return from JIRA Agent execution:' + JSON.stringify(errors);
          console.log(issueLink);
        }
        else {
          issueLink = "https://" + env.jira.host + "/browse/" + jiraKey;
        }
        bpUtils.updateBigPandaIncident(context, {}, SYSTEM, incidentId, issueLink, ackMessage);
    });
  }

  function ackMessage() {
    var params = {
      ReceiptHandle: event.receiptHandle,
      QueueUrl: queueName
    };

    SQS.deleteMessage(params, function (data) {
        console.log('Execution completed successfully.');
        if (data) {
            console.log(data);
        }
        callback();
    });
  }
}
function setupContext(context, env, config) {
  context.bpContext = {
    env: env,
    config: config
  };
}
function getAuthToken(env) {
  return env.bp ? env.bp.authToken : null;
}
