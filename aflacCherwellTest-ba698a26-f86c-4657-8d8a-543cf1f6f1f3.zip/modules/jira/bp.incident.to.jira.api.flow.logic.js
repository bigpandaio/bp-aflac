var REOPEN_ACTION = "Reopen";
var RESOLVE_ACTION = "Resolve";
var UPDATE_ACTION = "Update";
var JIRA_PORT = 443;
var BASE_JIRA_REQ_OPS = {};
var JIRA_BASE_PATH = '/rest/api/latest';
var bpUtils = require('modules/utils/bp-utils');

module.exports = {
    createIssue: createIssueAPI,
    updateIssue: updateIssueAPI,
    setupContext: setupContext
}


function setupContext(context, incident, env, config, customerLogic, logicParams) {

  env.jira.basePath = (env.jira.subDirectory || "") + (env.jira.basePath || JIRA_BASE_PATH);

  BASE_JIRA_REQ_OPS = {
    host: env.jira.host,
    port: JIRA_PORT,
    path: env.jira.basePath,
    agent: false,
    auth: env.jira.user + ':' + env.jira.password,
    headers: {
        'Accept'      : 'application/json',
        'Content-Type': 'application/json'
    }
  };
}

function createIssueAPI(context, fields, incident, callback) {
  var config = bpUtils.getConfig(context);
  var jiraReqBody = { 'fields': fields };
  var authToken = bpUtils.getAuthToken(context);

  let basePath = '/issue';
  let successCodes = 201;

  if (config.jiraCustom && config.jiraCustom.createIssue) {
    if (config.jiraCustom.createIssue.successCodes) { successCodes = config.jiraCustom.createIssue.successCodes; }
    if (config.jiraCustom.createIssue.basePath) { basePath = config.jiraCustom.createIssue.basePath; }
  }

  var jiraReqOpts = bpUtils.createRequestOptions(BASE_JIRA_REQ_OPS, 'POST', basePath);

  bpUtils.doApiCall(context, jiraReqOpts, jiraReqBody, 'JIRA', 'creating issue', successCodes, function(err, data) {
      // If everything is done by transitions, create should also trigger that.

      if (err) {
        return callback(err);
      }

      if (config.flow.transitionOnCreate) {
        performTransition(context,
                          incident,
                          {key: data.key},
                          UPDATE_ACTION,
                          config.flow.initialTransitionId,
                          fields,
                          afterCreation);

        (context, incident, issue, action, transitionId, fields, callback)
      } else {
        afterCreation();
      }

      return;

      function afterCreation() {
        if (config.flow.addAttachementOnCreate) {

          addAttachments(incident, data.key, env, customerLogic, saveAndUpdateBigPanda);
        } else {
          saveAndUpdateBigPanda();
        }
      }

      function saveAndUpdateBigPanda() {
        jiraKey = data.key;

        bpUtils.storeIncidentKeyMapping(context, context.bpContext.system, incident.id, jiraKey, authToken, function(err, data) {
          if (err) {
            return callback(err);
          }


          var issueLink = bpUtils.createRemoteLink(context, jiraKey);

          bpUtils.updateBigPandaIncident(context, {}, context.bpContext.system, incident.id, issueLink, callback);
        });
      }
  });
}

function updateIssueAPI(context, incident, key, fields, callback) {
  var config = bpUtils.getConfig(context);

  // In cases when we can't use transitions, this will force using the simple update
  if (config.flow.backwardCompatibility) {
    return updateJiraIssueFields(context, incident, key, fields, callback);
  }

  getJiraIssueInfo(context, incident, key, function(err, issue) {
      if (err) {
        return callback(err);
      }

      var updateAction = translateUpdateAction(config, incident, issue);

      // If Require update by transition enabled or not update. Other cases, use trigger.
      if (!config.flow.transitionOnUpdate && updateAction == UPDATE_ACTION) {
          updateJiraIssueFields(context, incident, key, fields, callback);
      } else {
          performTransition(context, incident, issue, updateAction, null, fields, callback);
      }
  });
}

function updateJiraIssueFields(context, incident, key, fields, callback) {

    if (!fields) {
        return;
    }

    var jiraReqBody = { 'fields': fields };

    doExistingJiraIssueApiCall(context, incident, key, '', jiraReqBody, 'updating issue', 201, 'PUT', callback);
}

// Implementation Functions

function performTransition(context, incident, issue, action, transitionId, fields, callback) {
    var currentChange = null;

    if (transitionId == null) {
        transitionId = getTransitionForAction(issue, action);
    }

    if (issue.fields) {
        currentChange = action + ' issue from: ' + issue.fields.status.name;
    } else {
        currnetChange = action + ' issue from creation';
    }

    if (!transitionId) {
        context.done(new Error('Cannot determine associated Transition ID for issue: ' + issue.key + ' with action: ' +  action));
        return;
    }

    var jiraReqBody = {
        'fields': fields,
        'transition': {
            'id': transitionId
        }
    };

    if (bpUtils.getConfig(context).flow.updateComments) {
        jiraReqBody.update = {
            "comment": [
                { "add": { "body": fields.description } }
            ]
        }
    }

    console.log("About to transition: " + issue.key + " for " + action + ' using: ' + transitionId + " with: " + JSON.stringify(fields))

    doExistingJiraIssueApiCall(
        context,
        incident,
        issue.key,
        '/transitions',
        jiraReqBody,
        currentChange,
        204,
        'POST',
        callback);
}

function getTransitionForAction(issue, action) {
    var transitionId = null;
    console.log(issue.transitions);
    // console.log(action);
    issue.transitions.forEach(function(transition) {
        if (transition.name == "BigPanda " + action) {
            transitionId = transition.id;
        }
    });

    return transitionId;
}


function addAttachments(incident, jiraIssueKey, env, customerLogic, callback) {
  var titleInfo = createIncidentTitleInfo(incident);

  customerLogic.getAttachments(incident, titleInfo, function(attachments) {
    pushAttachements(attachments, jiraIssueKey, env, function(res) {
      // No matter what - call the callback to finish
      // Error here shouldn't stop the completion
      callback();
    });
  });
}

function pushAttachements(attachments, jiraIssueKey, env, callback) {

  var options = {
      method: "POST",
      url: "https://" + env.jira.host + env.jira.basePath + "/issue/" + jiraIssueKey + "/attachments",
      auth: {
        user: env.jira.user,
        password: env.jira.password
      },
      headers: {
        "x-atlassian-token": "nocheck"
      }
  };

  var req = request.post(options, function(req, res) {
    console.log(res.body);
    callback(res);
  });

  var form = req.form();


  attachments.forEach(function(attachment) {
    console.log("Adding attachement " + attachment.filename + " for: " + jiraIssueKey);
    form.append('file', attachment.data, { filename: attachment.filename});
  });
}

function getJiraIssueInfo(context, incident, key, callback) {
    var config = bpUtils.getConfig(context);

    doExistingJiraIssueApiCall(
        context,
        incident,
        key,
        '?fields=summary,status,resolution,' + config.fieldMapping.incident.id + '&expand=transitions',
        'JIRA',
        'get issue info',
        200,
        'GET',
        callback);
}

// JIRA API

function doExistingJiraIssueApiCall(context, incident, jiraIssueKey, jiraReqPathSuffix, jiraReqBody, happening, successCode, method, callback) {
   if (jiraIssueKey) {
      var jiraReqOpts = bpUtils.createRequestOptions(BASE_JIRA_REQ_OPS, method || 'POST', '/issue/' + jiraIssueKey + jiraReqPathSuffix);

      bpUtils.doApiCall(context, jiraReqOpts, jiraReqBody, 'JIRA', happening, successCode, callback);
   } else {
      context.done(new Error('Cannot determine associated JIRA issue. Alert data lacks JIRA issue key tag.'));
   }
}

// --------------------------- FLOW DECISIONS ---------------------------

function translateUpdateAction(config, incident, issue) {
    var issueResolved = translateIssueResolution(issue);

    // This is a bit generic, maybe shouldn't be in the customization section

    // for now, the decision if to resolve or open a new ticket should
    // be in BigPanda, this is due to a decision have to ensure 1:1 mapping.

    if (incident.active && issueResolved) {
        return REOPEN_ACTION;
    }

    if (!incident.active && !issueResolved) {
      if (config.flow.noResolveOnClose) {
        console.log("Not Resolving - configured just to update");
      } else {
        return RESOLVE_ACTION;
      }
    }

    console.log("active: " + incident.active + ", ..., issueResolved:" + issueResolved );

    return UPDATE_ACTION;


    // TODO - is incident.active = !incident.resolved  ?
}

// Resolution customizations
function translateIssueResolution(issue) {
    return issue.fields.resolution !== null;
}
