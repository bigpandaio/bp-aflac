

// --------------------------- GENERIC CODE ---------------------------

// Constants

var BP_HOST = "api.bigpanda.io";
var BP_BASE_PATH = "/resources/v1.0/incidents";

var DB_SYSTEM = 'JIRA';
var SYSTEM = "Resolve JIRA";
var reqTimeout = 3000;

// Init

// Modules
var AWS = require('aws-sdk');
var http = require('https');

var bpUtils = require('../utils/bp-utils');

// DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();

// Localization
var TIME_OFFSET = '-0500';
process.env.TZ = 'America/New_York';

var AWS_REGION = "us-east-1";
AWS.config.update({ region: AWS_REGION });

var BASE_BP_REQ_OPS = {};

function setupContext(context, env, config) {
  context.bpContext = {
    env: env,
    config: config
  };

  bpIncidentToTicketTable = ("bp_" + config.customer.name + "_" + DB_SYSTEM + "_incident_to_ticket").toLowerCase();

  BASE_BP_REQ_OPS = {
      host: BP_HOST,
      port: 443,
      path: BP_BASE_PATH, // To be set dynamically with the incident Id.
      agent: false,
      headers: {
          'Content-Type': 'application/json'
      }
  };

  /**** Special Customizations ****/

}

// Main Flow
exports.handle = handle;

function handle(event, context, env, config) {
    setupContext(context, env, config);

    var normalizedJiraIssue = {
        comment: event.comment,
        user: event.user.displayName,
        jiraKey: event.issue.key,
        incidentId: event.issue.fields[config.fieldMapping.incident.id]
    };

    var incidentId = normalizedJiraIssue.incidentId;
    var jiraKey = normalizedJiraIssue.jiraKey;

    if (!incidentId) {
        context.done(new Error('Invalid incident - no mapped incidentId for key: ' + jiraKey));
        return;
    }

    bpUtils.extractIssueKeyEvent(context, SYSTEM, incidentId, function (storedMapping) {
        if (!!storedMapping) {
            resolveIncidentInBigPanda(
              context,
              normalizedJiraIssue,
              completion,
              storedMapping["auth_token"],
              storedMapping["bp_env"]);
        } else {
            context.done(new Error('Cannot find mapping for key: ' + jiraKey + ' and incident id: ' +  incidentId));
        }
    });

    function completion(data) {
        console.log('Execution completed successfully.');

        if (data) {
            console.log(data);
        }

        context.succeed();
    }
}


// BigPanda API Methods

function resolveIncidentInBigPanda(context, normalizedJiraIssue, completion, authToken, bpEnv) {
    var reqOpts = createRequestOptions(BASE_BP_REQ_OPS, 'POST', '/' + normalizedJiraIssue.incidentId);

    bpUtils.addRequestOverrides(reqOpts, getAuthToken(context, authToken), bpEnv);

    var comment = ' by ' + normalizedJiraIssue.user + " from " + SYSTEM;

    if (normalizedJiraIssue.comment) {
        comment += "\n" + normalizedJiraIssue.comment;
    }

    var reqBody = {
        resolved: true,
        comments: comment
    };

    doApiCall(context, reqOpts, reqBody, SYSTEM, 'resolving incident', [204, 409], completion);
}


// Generic Methods

// API

function doApiCall(context, reqOpts, reqBody, service, happening, successCodes, onSuccess) {
    var req = http.request(reqOpts, function (res) {
        // console.log(service + ' request in progress: ' + JSON.stringify(reqOpts));  // This can print the password so off by default
        console.log(service + ' request body sent: ' + JSON.stringify(reqBody));
        console.log(service + ' response status: ' + res.statusCode);

        res.on('data', function (chunk) {
            // console.log(service + ' response body: ' + chunk);
            var success = false;

            if (successCodes.constructor !== Array) {
                successCodes = [successCodes];
            }

            successCodes.forEach(function(successCode) {
                if (res.statusCode == successCode) {
                    success = true;
                }
            });

            if (success) {
                onSuccess(JSON.parse(chunk));
            } else {
                console.log('Error res: ' + new String(chunk));
                context.done(new Error(service + ' ' + happening + ' failed.'));
            }
        });
    });
    req.write(JSON.stringify(reqBody));
    req.end();

    req.on('error', function (err) {
        context.done(new Error(service + ' request error: ' + err.message));
    });
    req.setTimeout(reqTimeout, function () {
        context.done(new Error(service + ' request timeout after ' + reqTimeout + ' milliseconds.'));
    });
}

function createRequestOptions(baseReqOpts, method, path) {
  var options = Object.assign({}, baseReqOpts);

  if (path) {
    options.path += path;
  }

  if (method) {
      options.method = method;
  }

  return options;
}


// DB Store

function getEnv(context) {
  return context.bpContext.env;
}

function getAuthToken(context, overrideToken) {
  return overrideToken || getEnv(context).bp.authToken;
}

function getConfig(context) {
  return context.bpContext.config;
}

function getFlags(context) {
  return getConfig(context).flags || {}
}
