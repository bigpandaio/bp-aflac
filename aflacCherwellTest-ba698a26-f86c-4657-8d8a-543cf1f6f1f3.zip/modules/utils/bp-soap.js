const soap = require('soap');
const moment = require('moment');
const Promise = require('bluebird');

module.exports = function(config) {

  var soapClient = function() {
    var client = null;
    var initiated = false;
    var soapEndpoint = config.endpoint;

    return {
      invokeSoap: invokeSoap
    }

    function invokeSoap(operation, data) {

      return getClient().then(function() {
        var callPromise = Promise.fromCallback(client[operation].bind(client, data)).then(function(res) {
          console.log("Finished calling - " + operation, data);
          console.log("Result: ", res);

          return res;
        });

        callPromise.finally(function() {
          client.clearSoapHeaders();
        });

        return callPromise;
      }).catch(function(err) {
        console.log("Cannot call SOAP - " + operation, { err: err.message, data: data });

        return Promise.reject(err);
      });
    }

    function createClient() {
      var wsdlOptions = {
        disableCache: config.disableCache,
        overrideRootElement: config.rootElement
      };

      return Promise.fromCallback(soap.createClient.bind(soap, soapEndpoint, wsdlOptions)).then(function(createdClient) {
        console.log("Client Created");

        initiated = true;
        client = createdClient;

        if (config.basicAuth) {
            client.setSecurity(
              new soap.BasicAuthSecurity(config.basicAuth.user, config.basicAuth.password));
        }
      });
    }

    function getClient() {
      if (!initiated) {
        return createClient();
      } else {
        return Promise.resolve();
      }
    }
  }

  return soapClient;
}
