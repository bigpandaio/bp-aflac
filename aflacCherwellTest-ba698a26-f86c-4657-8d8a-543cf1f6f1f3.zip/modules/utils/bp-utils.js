// API
var http = require('https');
var request = require('request');
var _ = require('underscore');

var crypto = require('../crypto');

var REQ_TIMEOUT = 120000;


// AWS
var AWS_REGION = "us-east-1";
var AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION });
AWS.config.setPromisesDependency(require('bluebird'));

// DynamoDB
var docClient = new AWS.DynamoDB.DocumentClient();
var kms = new AWS.KMS();


// BigPanda config

var BP_HOST = "api.bigpanda.io";
var BP_BASE_PATH = "/resources/v1.0/incidents";

// Generic Utilities

function getAlertTagsData(incident, tag, onlyActive) {
    var tagData = [];

    incident.alerts.forEach(function(alertData) {
        var alertTagData = getAlertTagData(alertData, tag);

        if (alertTagData && (!onlyActive || alertData.active)) {
            tagData.push(alertTagData);
        }
    });

    var uniqTags = uniqStrings(tagData);

    if (uniqTags.length == 0) {
        return null;
    }

    return uniqTags.join(",");
}

function getAlertTagData(alertData, tag) {

    if (!alertData.tags || alertData.tags.constructor !== Array) {
        return null;
    }

    var value = null;

    alertData.tags.forEach(function (alertTag) {
        var tagKey = alertTag.name || alertTag.object || alertTag.type;

        if (tagKey && tag && tagKey.toLowerCase() == tag.toLowerCase()) {
            value = alertTag.value;
        }
    });

    if (value && _.isArray(value)) {
      value = value.join("|");
    }

    return value;
}

function capitalizeFirstLetter(str) {
    if (!str) {
        return str;
    }

    if (str.charAt(0) == '_') {
      str = str.slice(1);
    }

    return str.charAt(0).toUpperCase() + str.slice(1);
}

function sortIncidentAlerts(alerts) {
    alerts.sort(function(a, b) {
        return a.startedOn - b.startedOn;
    });

    return alerts;
}

function uniqStrings(arr) {
   var u = {}, a = [];

   for(var i = 0, l = arr.length; i < l; ++i){
      if(u.hasOwnProperty(arr[i])) {
         continue;
      }
      a.push(arr[i]);
      u[arr[i]] = 1;
   }

   return a;
}

function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';

  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;

  return hours + ':' + minutes + ' ' + ampm;
}

function formatLink(label, url, type) {
  if (type == "markdown") {
    return `[${label}|${url}]`;
  } else {
    return `<a target="_blank" href="${url}">${label}</a>`;
  }
}

function createRequestOptions(baseReqOpts, method, path) {
  var options = Object.assign({}, baseReqOpts);

  if (path) {
    options.path += path;
  }

  if (method) {
      options.method = method;
  }

  return options;
}

function addRequestOverrides(reqOpts, authToken, bpEnv) {
  if (!reqOpts.headers) {
    reqOpts.headers = {
      'Content-Type': 'application/json'
    }
  }

  if (bpEnv) {
    reqOpts.host = bpEnv + "-" + reqOpts.host;
  }

  reqOpts.headers['Authorization'] = 'Bearer ' + authToken;
}

function getIncidentConfig(incident) {
    var alert = incident.alerts[0];

    // Heck to overcome how nagios primary properties are getting sent.
    if (alert.sourceSystem.startsWith("nagios") ||
        alert.sourceSystem.startsWith("icinga")) {
        return {
            primaryProperty: "_host",
            secondaryProperty: "_check"
        }
    }

    return {
        primaryProperty: alert.primaryProperty,
        secondaryProperty: alert.secondaryProperty
    }
}


function getConfig(context) {
  return context.bpContext.config || {};
}

function getEnv(context) {
  return context.bpContext.env;
}

function getCustomerLogic(context) {
  return context.bpContext.customerLogic || {};
}

function getLogicParams(context) {
  return context.bpContext.logicParams || {};
}

function getAuthToken(context) {
  if (context.bpContext.overrideAuthToken) {
    return context.bpContext.overrideAuthToken;
  }

  var env = getEnv(context);

  return env.bp ? env.bp.authToken : null;
}

function getMetadata(context) {
  return context.bpContext.metadata || {};
}

function getFlags(context) {
  return getConfig(context).flags || {}
}


function extractMetadata(metadata) {
  var bpShare = {};

  if (metadata.sender && metadata.sender.email) {
    if (metadata.sender.email == "bigpanda@bigpanda.io") {
        bpShare.autoShared = true
    } else {
      bpShare.reportedBy = metadata.sender.email;
    }
  }

  bpShare.environment = metadata.environment;
  bpShare.environment_id = metadata.environment_id;
  bpShare.intialMessage = metadata.message;

  if (metadata.comment) {
    bpShare.comment = metadata.comment.comment;

    if (metadata.comment.performer) {
      bpShare.commentedBy = metadata.comment.performer.email;
      bpShare.commentedByName = metadata.comment.performer.name;
    }
  }

  if (bpShare.autoShared && bpShare.comment && !bpShare.commentedBy) {
    bpShare.externalComment = true;
  }

  return bpShare;
}

function createLinks(host, system, incident, metadata) {
  var source = '?bp_source=' + system.toLowerCase();

  var environment = 'all';
  var timelineUrl = null;

  if (metadata && metadata.environment_id) {
     environment = metadata.environment_id;
  }

  var incidentUrl = 'https://' + host + '/#/app/overview/' + environment +
                    '/active/incidents/' + incident.id;

  return {
    incidentUrl: incidentUrl + source,
    timelineUrl: incidentUrl + '/timeline' + source,
    landingPageUrl: incident.links.landingPage
  }
}

function findHeaderValue(name, event) {
  // Check for value in request headers
  if (event.params) {
    for (header in event.params.header) {
      const fieldStart = header.indexOf('x-bp-config-');
      const fieldValue = event.params.header[header];

      if (fieldStart == 0 && fieldValue) {
        const configField = header.substring(12);
        if (configField === name) {
          return fieldValue;
        }
      }
    }
  }

  return null;
}


// DB Store

function extractIssueKeyEvent(context, system, incidentId, callback) {
  extractIssueData(context, system, incidentId, function(err, data) {
    var ticketKey = (err || !data) ? null : data.ticket_key;

    callback(err, ticketKey);
  });
}

function extractIssueData(context, system, incidentId, callback) {
  var key = {
    outbound_system: context.primaryKey || system,
    incident_id: incidentId,
  }

  getDynamoData(getIncidentTableName(context, system), key, callback);
}

function storeIncidentKeyMapping(context, system, incidentId, key, authToken, callback) {
  return storeIncidentData(context, system, incidentId, null, key, authToken, callback);
}

function storeIncidentData(context, system, incidentId, incidentStatus, key, additionalData, callback) {

  var mapping = {};

  if (additionalData && _.isObject(additionalData)) {
    _.extend(mapping, additionalData);

    // Backwards compatibility to when the additional Data was authToken
    // It should be stored as auth_token not authToken and that's happeing below;
    delete mapping.authToken; 
  } else if (_.isString(additionalData)) {
    // Backwards compatibility to when the additional Data was authToken
    additionalData = {authToken: additionalData};
  }

  _.extend(mapping, {
      outbound_system: system,
      incident_id: incidentId,
      ticket_key: key,
      last_status: incidentStatus,
      timestamp: new Date().getTime()
  });

  var config = getConfig(context);

  if (getFlags(context).saveAuthToken) {
    mapping.auth_token = additionalData.authToken;

    if (config.BPEnv) {
      mapping.bp_env = config.BPEnv;
    }
  }

  return storeDynamoData(getIncidentTableName(context, system), mapping, callback);
}

function storeDynamoData(table, item, callback) {
  var params = {
    TableName: table,
    Item: item
  };

  console.log("Adding a new item");

  docClient.put(params, function(err, data) {
    if (err) {
      console.error("Unable to add Item Error JSON:", JSON.stringify(err, null, 2));
      callback(err);
    } else {
      console.log("Added Item", item);
      callback(null, data);
    }
  });
}

function getDynamoData(table, key, callback) {
  var params = {
    TableName: table,
    Key: key
  };

  docClient.get(params, function(err, data) {

    if (err) {
      console.log('Error in get key from dynamo' + JSON.stringify(err, null, 2));
      return callback(err);
    }

    console.log("Found data", JSON.stringify(data, null, 2));

    if (!!data.Item) {
      callback(null, data.Item);
    } else {
      callback(null, null);
    }
  });
}

function getIncidentTableName(context, system) {
  var config = getConfig(context);
  var dbUniqueName = config.customer.name;

  if (config.customer.env) {
    dbUniqueName += "_" + config.customer.env;
  }

  return ("bp_" + dbUniqueName + "_" + system + "_incident_to_ticket").toLowerCase();
}


// Generic API

function doApiCall(context, reqOpts, reqBody, service, happening, successCodes, callback) {
  var config = getConfig(context);

  var maxTimeoutRetries = getAPIMaxTriesForAction(config, happening);
  var retries = 0;

  console.log("Making a call for: " + service);

  singleAPICall(context, retries, reqOpts, reqBody, happening, successCodes, onAPISuccess, onAPITimeout, onError);

  function onAPISuccess(retryId, data) {
    if (retryId != retries) {
      console.log("Ignoring result - invalid retryId: " + retryId);
      return;
    }

    callback(null, data);
  }

  function onAPITimeout() {
    if (retries >= maxTimeoutRetries) {
      callback(happening + ' - timeout after retrying: ' + retries);
      return;
    }

    retries++;
    console.log(happening + " - (" + retries + ") retry after timout");

    return singleAPICall(context, retries, reqOpts, reqBody, happening, successCodes, onAPISuccess, onAPITimeout, onError);
  }

  function onError(err) {
    callback(err);
  }

}

function singleAPICall(context, retryId, reqOpts, reqBody, happening, successCodes, onSuccess, onTimeout, onError) {
  var formattedRequest = JSON.stringify(reqBody);

  // DEBUG to set content-length for Cisco
  reqOpts.headers['Content-Length'] = Buffer.byteLength(formattedRequest);
  //console.log('request options: ' + JSON.stringify(reqOpts));

  console.log(' request body sent: ' + formattedRequest);

  var req = http.request(reqOpts, function (res) {
      var data = null;
      var success = false;

      res.on('data', function (chunk) {
          console.log(' response body: ' + chunk);
          if (data == null) {
            data = [];
          }

          data.push(chunk);
      });

      res.on('end', function() {

        if (!data) {
            onSuccess(retryId); // No data
            return;
        }

        if (successCodes.constructor !== Array) {
            successCodes = [successCodes];
        }

        successCodes.forEach(function(successCode) {
            if (res.statusCode == successCode) {
                success = true;
            }
        });

        var resultStr = data.join('');

        if (success) {
            // TODO - Validate Json
            onSuccess(retryId, JSON.parse(resultStr));
        } else {
            onError(' Invalid return code: ' + resultStr);
        }
      });
  });

  req.write(formattedRequest);
  req.end();

  req.on('error', function (err) {
      onError(' request error: ' + err.message);
  });

  req.setTimeout(REQ_TIMEOUT, onTimeout);
}

function getAPIMaxTriesForAction(config, action) {
  // don't allow any retries on incident creation - having a retry might
  // cause multiple tickets.
  if (action === 'creating issue') {
    return 0;
  }

  return 2;
}

// BigPanda API Utils

function updateBigPandaIncident(context, opts, comment, incidentId, issueLink, callback) {

    var bpHost = BP_HOST;
    if (getFlags(context).bpHostPrefix) {
      bpHost = getFlags(context).bpHostPrefix + "-" + BP_HOST;
    }

    var BASE_BP_REQ_OPS = {
        host: bpHost,
        port: 443,
        path: BP_BASE_PATH, // To be set dynamically with the incident Id.
        agent: false,
        headers: {
            'Content-Type': 'application/json'
        }
    };

    var reqOpts = createRequestOptions(BASE_BP_REQ_OPS, 'POST', '/' + incidentId);

    addRequestOverrides(reqOpts, getAuthToken(context));

    var reqBody = {
        comments: (issueLink != null) ? (comment + ' issue link: ' + issueLink) : comment
    };

    if (opts && opts.resolve) {
      reqBody.resolved = true;
    }

    doApiCall(context, reqOpts, reqBody, comment, 'update BigPanda incident', 204, callback);
}


function createRemoteLink(context, key) {
    var env = getEnv(context);
    var jiraEnv = env.jira;

    var jiraInternalHost = jiraEnv.internalHost || jiraEnv.host;
    return "https://" + jiraInternalHost + "/browse/" + key;
}

function encryptData(keyId, plainData) {
  var encryptParams = {
      KeyId: keyId,
      KeySpec: "AES_256"
  };

  return kms.generateDataKey(encryptParams).promise().then((kmsData) => {
    var cryptoHelper = new crypto.Helper(kmsData.Plaintext.toString('base64'));

    return {
      body: cryptoHelper.encrypt(plainData),
      key: kmsData.CiphertextBlob.toString('base64')
    };
  });
}

function decryptData(message) {
  var plainData = []

  var envelopeBuffer = new Buffer(message.key, 'base64');

  return kms.decrypt({CiphertextBlob: envelopeBuffer}).promise().then((kmsData) => {

    var cryptoHelper = new crypto.Helper(kmsData.Plaintext.toString('base64'));
    var result = cryptoHelper.decrypt(message.body.toString('utf-8'));

    return result;
  });
}

function decryptValue(encrypted) {
  return kms.decrypt({ CiphertextBlob: new Buffer(encrypted, 'base64') }).promise().then((data) => {
    return data.Plaintext.toString('ascii');
  });
}

function getIncidentData(incidentId, token) {
  return new Promise((resolve, reject) => {
    request.get({
      headers: {
        'Authorization': 'Bearer ' + token,
        'Accept': 'application/json',
        'Content-Type': 'application/json; charset=utf8'
      },
      url: 'https://api.bigpanda.io/resources/v1.0/incidents/' + incidentId + '?expand=alerts'
    }, function(err, response, resBody){
      if (err) { reject(err); }
      else {
        try { JSON.parse(resBody); }
        catch (e) { reject('Invalid Incident'); }
        resolve(JSON.parse(resBody));
      }
    });
  });
}

module.exports = {
  getAlertTagsData: getAlertTagsData,
  getAlertTagData: getAlertTagData,
  capitalizeFirstLetter: capitalizeFirstLetter,
  sortIncidentAlerts: sortIncidentAlerts,
  uniqStrings: uniqStrings,
  formatAMPM: formatAMPM,
  formatLink: formatLink,
  createRequestOptions: createRequestOptions,
  getIncidentData: getIncidentData,

  addRequestOverrides: addRequestOverrides,

  getIncidentConfig: getIncidentConfig,

  getFlags: getFlags,
  getAuthToken: getAuthToken,
  getCustomerLogic: getCustomerLogic,
  getEnv: getEnv,
  getConfig: getConfig,
  getMetadata: getMetadata,
  getLogicParams: getLogicParams,
  createLinks: createLinks,
  findHeaderValue: findHeaderValue,

  extractMetadata: extractMetadata,

  doApiCall: doApiCall,

  extractIssueKeyEvent: extractIssueKeyEvent,
  storeIncidentKeyMapping: storeIncidentKeyMapping,

  updateBigPandaIncident: updateBigPandaIncident,
  createRemoteLink : createRemoteLink,

  getDynamoData: getDynamoData,
  storeDynamoData: storeDynamoData,

  encryptData: encryptData,
  decryptData: decryptData,
  decryptValue: decryptValue,

  extractIssueData: extractIssueData,
  storeIncidentData: storeIncidentData
}
