'use strict';var pollUntil=require('./poll-until');

module.exports=function(config,logger){
var pollUntilInstance=pollUntil(config,logger);

return function(classToWrap){
logger.info('Wrapping '+classToWrap.prototype.constructor.name+' with until');
Object.getOwnPropertyNames(classToWrap.prototype).filter(function(p){return p!=='constructor';}).forEach(function(methodName){
logger.info('Wrapping '+methodName+' with until at '+classToWrap.prototype.constructor.name);
Object.defineProperty(classToWrap.prototype,methodName+'Until',{value:function wrapped(){
logger.info('in Wrapped function',methodName);for(var _len=arguments.length,argsArray=Array(_len),_key=0;_key<_len;_key++){argsArray[_key]=arguments[_key];}
var predicate=argsArray.pop();
return pollUntilInstance(classToWrap.prototype[methodName],this,argsArray,predicate);
}});

});
};
};