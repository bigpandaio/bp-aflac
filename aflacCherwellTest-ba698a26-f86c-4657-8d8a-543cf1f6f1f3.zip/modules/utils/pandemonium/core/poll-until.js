'use strict';var Promise=require('bluebird');

var MAX_RETRIES=25;
var MAX_DELAY=9000;

module.exports=function(config,logger){
var recursivePoll=function recursivePoll(funcWrapped,predicate,retriesLeft,delayPerPolling){
logger.info('In recursivePoll, retries left: '+retriesLeft);
if(retriesLeft===0){
throw new Error('Reached retry limit without correct polling result');
}

return funcWrapped().then(function(result){
logger.info('In recursivePoll after getting results');
if(predicate(result)){
logger.info('Predicate validated succesfully, returning content');
return result;
}
logger.info('Predicate failed, waiting for '+delayPerPolling);
return Promise.delay(delayPerPolling).then(function(){
logger.info('After polling delay');
return recursivePoll(funcWrapped,predicate,retriesLeft-1,delayPerPolling);
});
});
};
return function(funcToCall,thisContext){var funcArguments=arguments.length>2&&arguments[2]!==undefined?arguments[2]:[];var predicateFunc=arguments[3];var retriesCount=arguments[4];var delayPerPolling=arguments[5];
var retries=retriesCount||(config.polling&&config.polling.retriesCount?config.polling.retriesCount:15);
if(retries>MAX_RETRIES){
retries=MAX_RETRIES;
}
var delay=delayPerPolling||(config.polling&&config.polling.delayPerPolling?config.polling.delayPerPolling:500);
if(delay>MAX_DELAY){
delay=MAX_DELAY;
}
var call=function call(){return funcToCall.apply(thisContext,funcArguments);};

logger.info('In polling, got '+retries+' retries and '+delayPerPolling+' delay');

return recursivePoll(call,predicateFunc,retries,delay);
};
};