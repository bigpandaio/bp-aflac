'use strict';var Promise=require('bluebird');
var lodash=require('lodash');
var clientLoader=require('./client-loader');

module.exports=function(config,logger){
var clientLoaderInstance=clientLoader(config,logger);

return function(){
logger.info('Running health checks');
var configuredClientUrls=Object.keys(config).
filter(function(key){return key.endsWith('Url');}).
map(function(key){return lodash.dropRight(key,3).join('');});

var healthCheckPromises=configuredClientUrls.map(function(clientCamelCased){return(
clientLoaderInstance[clientCamelCased].callHealthUrl().
catch(function(err){
throw new Error('Health Check failed on '+clientCamelCased+': '+err.message);
}));});


return Promise.all(healthCheckPromises).
then(function(){return true;});
};
};