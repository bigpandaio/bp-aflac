'use strict';var randomOrgGenerator=require('./random-organization-generator');
var lodash=require('lodash');
var clientLoader=require('./client-loader');

module.exports=function(config,logger){
var clients=clientLoader(config,logger);

return function(){
var org=randomOrgGenerator(config,logger);
logger.info('Generating organization',org.name);
return clients.webApi.login(config.adminUser.email,config.adminUser.password).
then(function(loginResult){
logger.info('Logged in as root user with token',loginResult.token);
// WebApiClient that points to the root (bigpanda-admins) organization
return new clients.webApi({referrer:{token:loginResult.token}}).
signup(org.name,org.referrer.email,org.referrer.password,org.referrer.name).
then(function(createdOrganization){
logger.info('Finished signing up random organization',createdOrganization.name);
return{
organization:createdOrganization,
// clients will hold all the api clients already instanciated with the created organization
clients:lodash.keys(clients).reduce(function(clientDict,client){
logger.info('Instantiating '+client);
clientDict[client]=new clients[client](createdOrganization);// eslint-disable-line no-param-reassign
return clientDict;
},{}),
cleanup:function cleanup(){
// TBD - call to orchestrator to delete organization
logger.info('Cleanup');
}};

});
});
};
};