'use strict';var randomizer=function randomizer(){return Math.random().toString(36).substring(3);};
module.exports=function(config,logger){
logger.info('Generating random organization');
var orgName=(config.generatedOrgPrefix||'rand')+'-'+randomizer()+'-ium';
var org={
name:orgName,
referrer:{
email:'referrer@'+orgName+'.com',
password:randomizer().toUpperCase()+'#$#@'+randomizer().toLowerCase(),
name:'Random Referrer'}};



logger.info('Finished generating random organization',org.name);

return org;
};