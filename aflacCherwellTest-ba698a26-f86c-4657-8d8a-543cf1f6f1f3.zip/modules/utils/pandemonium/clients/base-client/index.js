'use strict';var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}var request=require('../../core/request-wrapper');
var untilWrapper=require('../../core/monkey-patch-class-with-poll');
var lodash=require('lodash');

module.exports=function(config,logger){
var untilWrapperInstance=untilWrapper(config,logger);var
BaseClient=function(){_createClass(BaseClient,null,[{key:'validateHttpResponse',value:function validateHttpResponse()




{var validHttpCode=arguments.length>0&&arguments[0]!==undefined?arguments[0]:200;var errorFormatter=arguments[1];
return function(res){
if(res.response.statusCode!==validHttpCode){
throw new Error(errorFormatter?errorFormatter(res.body):res.body);
}
return res.body;
};
}},{key:'serviceName',get:function get(){return'base-client';}}]);

function BaseClient(organization){_classCallCheck(this,BaseClient);
this.organization=organization;
}_createClass(BaseClient,[{key:'callHttpWithAccessToken',value:function callHttpWithAccessToken(

options){
logger.info('BaseClient calling Http with access token',options.uri,this.organization.referrer.token);
return request(lodash.merge(options,{
qs:{
access_token:this.organization.referrer.token}}),

logger).then(function(res){
logger.info('Back from http with access token',res.response.statusCode);
return res;
});
}},{key:'callHttpWithBearer',value:function callHttpWithBearer(

options){
logger.info('BaseClient calling Http with bearer',options.uri,this.organization.apiToken);
return request(lodash.merge(options,{
headers:{
Authorization:'Bearer '+this.organization.apiToken}}),

logger);
}}],[{key:'callHealthUrl',value:function callHealthUrl(

url){
var healthUrl=url+'/health/'+this.serviceName;
logger.info('calling health url',healthUrl);
return request({
uri:healthUrl},
logger).
then(BaseClient.validateHttpResponse());
}},{key:'untilWrapper',value:function untilWrapper()

{
untilWrapperInstance(this);
}}]);return BaseClient;}();


BaseClient.untilWrapper();

return BaseClient;
};