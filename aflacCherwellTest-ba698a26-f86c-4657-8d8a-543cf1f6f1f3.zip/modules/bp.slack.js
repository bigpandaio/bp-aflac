const WebClient = require('@slack/client').WebClient;

module.exports = {
  postMessage: (postChannel, postString, CONFIG) => {
    return new Promise((resolve, reject) => {
      const web = new WebClient(CONFIG.slack.apiToken);
      web.chat.postMessage(postChannel, postString, {link_names:1}, (err, res) => {
        if (err) {
          console.log('ERROR: Failed to post to slack:\n' + err);
          reject(err)
        } else {
          console.log('Message sent: ', res);
          resolve(true);
        }
      });
    });
  },
  createChannel: (channelName, CONFIG) => {
    return new Promise((resolve, reject) => {
      const web = new WebClient(CONFIG.slack.apiToken);
      web.channels.create(channelName, (err, res) => {
        if (err) {
          console.log('ERROR: Failed to create channel\n' + err);
          reject(err);
        } else if (res.ok && res.channel) {
          console.log('Channel Created: ', res);
          resolve(res.channel.id);
        } else {
          console.log('Invalid Response: ', res);
          resolve(null);
        }
      });
    });
  },
  updateChannel: (channelName, channelPurpose, CONFIG) => {
    return new Promise((resolve, reject) => {
      const web = new WebClient(CONFIG.slack.apiToken);
      web.channels.setPurpose(channelName, channelPurpose, (err, res) => {
        if (err) { console.log('ERROR: Failed to update channel purpose\n' + err); }
        web.channels.setTopic(channelName, channelPurpose, (err, res) => {
          if (err) { console.log('ERROR: Failed to update channel topic\n' + err); }
          resolve(true);
        });
      });
    });
  }
}
