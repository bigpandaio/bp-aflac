const bpUtils = require('./utils/bp-utils');

const AWS_REGION = "us-east-1";
const AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION });
AWS.config.setPromisesDependency(require('bluebird'));

const SQS = new AWS.SQS({region : 'us-east-1'});

function generateSQSMessages(config, incidentObj) {
  const queueName = config.sqs.queueName;
  let sqsMessages = [];

  if (incidentObj.status !== 'Ok') {
    console.log('Ignoring non-resolve event');
  } else {
    incidentObj.alerts.forEach(alert => {
      let msgPayload = { command: "closeSpectrum", payload: { clear_alarm_id: '' }, entity_id: '', incident_id: incidentObj.id };

      if (!bpUtils.getAlertTagData(alert, 'alarm_id')) {
        console.log('Ignoring alert missing alarmId');
      } else {
        msgPayload.entity_id = alert.id;
        msgPayload.payload.clear_alarm_id = bpUtils.getAlertTagData(alert, 'alarm_id');
        sqsMessages.push(msgPayload);
      }
    });
  }

  return sqsMessages;
}

function sendSQSMesages(config, msgPayload, callback){
  return new Promise((resolve, reject) => {
    const queueUrl = config.sqs.queueUrl;
    console.log('Sending following message payload to SQS')
    console.log(JSON.stringify(msgPayload))
    const params = {
      MessageBody: JSON.stringify(msgPayload),
      QueueUrl: queueUrl,
      MessageGroupId: 'spectrum'
    };

    SQS.sendMessage(params, function(err,data){
     if (err) { reject(err); }
     else { resolve(true); }  // SUCCESS
    });
  });
}

exports.handler = function (event, context, env, config, callback) {
  let sqsRequests = [];
  const sqsMessages = generateSQSMessages(config, event.incident);

  sqsMessages.forEach(message => {
    sqsRequests.push(sendSQSMesages(config, message, callback));
  });

  Promise.all(sqsRequests)
  .then(() => { callback(null, {statusCode: 200}); })
  .catch(err => { callback(err); });
}
