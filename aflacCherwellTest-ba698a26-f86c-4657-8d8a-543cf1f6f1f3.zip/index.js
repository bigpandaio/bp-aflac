const cherwellHandler = require('./modules/bp.cherwell');
const bpUtils = require('./modules/utils/bp-utils');
const bpFormatUtils = require('./modules/utils/bp-format-utils');

// ---------------------------  CONFIGURATION  ---------------------------

const CONFIG = {
  cherwell: {
    url: process.env.REST_URL || 'https://aflactest.cherwellondemand.com/CherwellAPI',
    incidentUrl: process.env.INCIDENT_URL || 'https://localhost/CherwellClient/Access/Command/Queries.GoToRecord?BusObID=BusinessObjectName&RecID=',
    host: process.env.HOST || 'localhost',
    userId: process.env.USER_ID || 'CSDAdmin',
    password: process.env.PASSWORD || 'CSDAdmin',
    clientId: process.env.CLIENT_ID || '',
    includeLinks: false,
    restApi: true
  },

  dynamoTable: process.env.DYNAMO_TABLE || 'bp_aflac_cherwell_test',

  customer: {
    name: process.env.CUSTOMER || 'aflac',
    token: process.env.TOKEN || ''
  },

  BPHostLink: 'a.bigpanda.io',
  SYSTEM: 'Cherwell'
};

const CUSTOM_FIELD_PREFIX = "x-bp-field-cherwell";

// ---------------------------  CUSTOMIZATIONS  ---------------------------

function createCherwellIncidentJson(incident, context, isRetry) {
  // const status = 'New';
  // const customer = 'bigpanda';
  const source = 'Event';
  // const requestor = context.reportedByEmail || 'BigPanda';
  //const priority = (incident.status === 'Critical') ? 'High' : 'Low';
  const priority = bpUtils.getAlertTagsData(incident, 'bp_priority') || '3';
  
  // Add DyanTrace URL to description
  let problem_url = bpUtils.getAlertTagsData(incident, 'problem_url') || '';
  if (problem_url) {
    problem_url = "DynaTrace URL: " + problem_url;
  }
  
  const tags = bpUtils.getAlertTagsData(incident, 'tags') || '';
  
  // generate Incident Link and prepend to description
  const bpIncidentLink = ('BigPanda: https://' + CONFIG.BPHostLink + '/#/app/overview/' + context.environmentId +
                    '/active/incidents/' + incident.id) || "";
  
  let description = bpFormatUtils.createIncidentDescription(context.bpContext.config, incident) ;
  description = description + "\n " + problem_url;
  description = bpIncidentLink + "\n" + description;
  description = description + "\n Tags: \n" + tags;
  
  const shortDescription = bpFormatUtils.customizeTitle(context.bpContext.config, incident, 140);
  const service = (bpUtils.getAlertTagsData(incident, 'service') && !isRetry) ? bpUtils.getAlertTagsData(incident, 'service').split(',')[0] : 'Service Desk';
  const category = (bpUtils.getAlertTagsData(incident, 'category') && !isRetry) ? bpUtils.getAlertTagsData(incident, 'category').split(',')[0] : 'Monitoring Submission';
  const subcategory = (bpUtils.getAlertTagsData(incident, 'subcategory') && !isRetry) ? bpUtils.getAlertTagsData(incident, 'subcategory').split(',')[0] : 'Report Incident';
  const customerDisplayName = 'BigPanda Integration';
  // const ownedByTeam = (bpUtils.getAlertTagsData(incident, 'bp_assignmentgroup')) ? bpUtils.getAlertTagsData(incident, 'bp_assignmentgroup').split(',')[0] : 'DCC';

  // let incidentLinks = '';
  // if (context.bpContext.config.cherwell.includeLinks) {
  //   incidentLinks = bpFormatUtils.formatInfoText(context.bpContext.config, incident) || ' ';
  // }

  return {
    busObId: "6dd53665c0c24cab86870a21cf6434ae",
    busObPublicId: "",
    busObRecId: "",
    cacheKey: "",
    cacheScope: "Tenant",
    fields: [
      {
        "dirty": true,
        "displayName": "Description",
        "fieldId": "252b836fc72c4149915053ca1131d138",
        "html": null,
        "name": "Description",
        // "value": description.replace(/\n/g,'<br>')
        "value": description
      },
      {
        "dirty": true,
        "displayName": "Priority",
        "fieldId": "83c36313e97b4e6b9028aff3b401b71c",
        "html": null,
        "name": "Priority",
        //"value": "1"
        "value": priority
      },
      {
        "dirty": true,
        "displayName": "Customer ID",
        "fieldId": "933bd530833c64efbf66f84114acabb3e90c6d7b8f",
        "html": null,
        "name": "Customer ID",
        "value": "93db6da57bde4b909d98d340d59e22c974abd9c903"
      },
      {
        "dirty": true,
        "displayName": "Customer Display Name",
        "fieldId": "93734aaff77b19d1fcfd1d4b4aba1b0af895f25788",
        "html": null,
        "name": "Customer Display Name",
        "value": customerDisplayName
      },
      {
        "dirty": true,
        "displayName": "Short Description",
        "fieldId": "BO:6dd53665c0c24cab86870a21cf6434ae,FI:93e8ea93ff67fd95118255419690a50ef2d56f910c",
        "html": null,
        "name": "Short Description",
        "value": shortDescription
      },
      {
        "dirty": true,
        "displayName": "Call Source",
        "fieldId": "93670bdf8abe2cd1f92b1f490a90c7b7d684222e13",
        "html": null,
        "name": "Call Source",
        "value": source
      },
      // {
      //   "dirty": true,
      //   "displayName": "Owned by team",
      //   "fieldId": "9339fc404e8d5299b7a7c64de79ab81a1c1ff4306c",
      //   "html": null,
      //   "name": "Owned by team",
      //   "value": ownedByTeam
      // },
      // {
      //   "dirty": true,
      //   "displayName": "Owned by Team ID",
      //   "fieldId": "9339fc404e312b6d43436041fc8af1c07c6197f559",
      //   "html": null,
      //   "name": "Owned by Team ID",
      //   "value": "9459bfd5974fa99a1260f640f1bdb4e4c810dc05e"
      // },
      {
        "dirty": true,
        "displayName": "BigPanda ID",
        "fieldId": "9456a6a7d5b74ecb20827e48768a3aa377b1bc4040",
        "html": null,
        "name": "BigPanda ID",
        "value": incident.id
      },
      {
        "dirty": true,
        "displayName": "Service",
        "fieldId": "936725cd10c735d1dd8c5b4cd4969cb0bd833655f4",
        "html": null,
        "name": "Service",
        "value": service
      },
      {
        "dirty": true,
        "displayName": "Category",
        "fieldId": "9e0b434034e94781ab29598150f388aa",
        "html": null,
        "name": "Category",
        "value": category
      },
      {
        "dirty": true,
        "displayName": "Subcategory",
        "fieldId": "1163fda7e6a44f40bb94d2b47cc58f46",
        "html": null,
        "name": "Subcategory",
        "value": subcategory
      }
    ],
    persist: true
  };
}

// ---------------------------    MAIN FLOW     ---------------------------

exports.handler = function (event, context, callback) {
  console.log('New Incident Received:');
  console.log(JSON.stringify(event));

  // Process custom headers and corresponding values
  if (event.headers) {
    CONFIG.custom_cherwell_fields = [];
    for (let header in event.headers) {
      let fieldStart = header.indexOf(CUSTOM_FIELD_PREFIX);
      if (fieldStart === 0 && event.headers[header]) {
        CONFIG.custom_cherwell_fields.push({
          fieldName: header.substring(fieldStart + CUSTOM_FIELD_PREFIX.length),
          fieldValue: event.headers[header]
        });
      }
    }
  }

  // Parsing the reporterBy to be the data we receive from the metadata.
  if (event.metadata && event.metadata.sender && event.metadata.sender.name && event.metadata.sender.email != 'bigpanda@bigpanda.io') {
    context.reportedBy = event.metadata.sender.name;
    context.reportedByEmail = event.metadata.sender.email;
    console.log('Setting requester: ' + context.reportedBy);
  }

  try { JSON.parse(event.body).incident; }
  catch (e) { return callback('Invalid Incident'); }

  const bpIncident = JSON.parse(event.body).incident;
  const metadata = JSON.parse(event.body).metadata;
  if (metadata.environment_id) {
    context.environmentId = metadata.environment_id;
  }
  context.bpContext = {
    config: CONFIG,
    incidentId: bpIncident.id,
    env: { bp: { authToken: CONFIG.customer.token } }
  };

  const incidentJsonString = createCherwellIncidentJson(bpIncident, context);

  return cherwellHandler.handler(incidentJsonString, context, CONFIG, (err, res) => {
    if (err) {
      try { JSON.parse(err).errorCode; }
      catch (e) { return callback('Invalid Incident'); }

      if (JSON.parse(err).errorCode === 'ValueNotValid') {
        const incidentRetryJsonString = createCherwellIncidentJson(bpIncident, context, true);
        return cherwellHandler.handler(incidentRetryJsonString, context, CONFIG, callback);
      } else {
        callback(err);
      }
    } else {
      callback(null, res);
    }
  });
}
