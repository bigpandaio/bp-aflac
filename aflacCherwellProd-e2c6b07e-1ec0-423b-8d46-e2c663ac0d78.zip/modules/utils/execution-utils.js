var fs = require('fs');

var ENV_FILE = "./env-secret.json";

var AWS_REGION = "us-east-1";
var AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION });
var kms = new AWS.KMS();

// Generic Lambda utils

function executionFailSafe(context, config, success) {
  if (!config.functionName) {
    context.done(new Error("No executed functionName defined"));
    return;
  }

  if (context.functionName != config.functionName) {
    context.done(new Error("Can't execute function " + context.functionName + " with code: " + config.functionName));
    return;
  }

  if (config.customer.keyId) {
    decryptEnv(context, config.customer.keyId, success);
  } else {
    success({})
  }
}

/**
 * Encrypt using:
 * aws kms encrypt --key-id KEY_ID  --plaintext file://env-plain.json --query CiphertextBlob --output text | base64 -D > ./env-secret.json
 *
 * Decrypt Using:
 * aws kms decrypt --ciphertext-blob fileb://env-secret.json --query Plaintext --output text | base64 --decode
 */

function decryptEnv(context, keyId, callback) {
  var encryptedSecret = fs.readFileSync(ENV_FILE);

  var params = {
    "CiphertextBlob": encryptedSecret
  };

  kms.decrypt(params, function(err, data) {
    if (err) {
      context.done(new Error("Can't decrypt env: " + err.stack));
    } else {
      callback(JSON.parse(data['Plaintext'].toString()));
    }
  });
}



module.exports = {
  executionFailSafe: executionFailSafe,
  decryptEnv: decryptEnv
}
