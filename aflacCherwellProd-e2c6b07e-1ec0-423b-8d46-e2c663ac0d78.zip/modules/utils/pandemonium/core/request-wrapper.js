'use strict';var Promise=require('bluebird');
var request=require('request');

var requestWithPromise=Promise.promisify(request,{multiArgs:true});

module.exports=function(options,logger){
logger.info('Before calling',options.uri,options.method);
return requestWithPromise(options).spread(function(response,body){
logger.info('Back from calling',options.uri,response.statusCode);
return{
response:response,
body:body};

});
};