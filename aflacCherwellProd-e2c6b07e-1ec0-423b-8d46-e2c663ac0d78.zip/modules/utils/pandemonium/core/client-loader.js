'use strict';var glob=require('glob');
var lodash=require('lodash');
var path=require('path');

var clientsBasePath=path.join(__dirname,'../clients');


module.exports=function(config,logger){return(
glob.sync(clientsBasePath+'/**/index.js').
reduce(function(clientModules,clientFile){
var dirname=lodash.camelCase(lodash.last(path.dirname(clientFile).split('/')));
clientModules[dirname]=require(clientFile)(config,logger);// eslint-disable-line no-param-reassign,global-require
return clientModules;
},{}));};