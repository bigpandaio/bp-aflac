'use strict';var clientLoader=require('./core/client-loader');
var pollUntil=require('./core/poll-until');
var initModule=require('./core/init');
var devNullLogger=require('log-devnull');
var healthCheck=require('./core/health-check');


module.exports=function(config){var logger=arguments.length>1&&arguments[1]!==undefined?arguments[1]:devNullLogger;return{
// Api Clients Classes
clients:clientLoader(config,logger),
init:initModule(config,logger),
pollUntil:pollUntil(config,logger),
healthCheck:healthCheck(config,logger)};};