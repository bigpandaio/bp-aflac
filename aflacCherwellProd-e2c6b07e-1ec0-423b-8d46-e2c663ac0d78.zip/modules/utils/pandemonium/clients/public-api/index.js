'use strict';var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _get=function get(object,property,receiver){if(object===null)object=Function.prototype;var desc=Object.getOwnPropertyDescriptor(object,property);if(desc===undefined){var parent=Object.getPrototypeOf(object);if(parent===null){return undefined;}else{return get(parent,property,receiver);}}else if("value"in desc){return desc.value;}else{var getter=desc.get;if(getter===undefined){return undefined;}return getter.call(receiver);}};function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var lodash=require('lodash');
var baseClientModule=require('../base-client');

module.exports=function(config,logger){
var BaseClient=baseClientModule(config,logger);var

PublicApiClient=function(_BaseClient){_inherits(PublicApiClient,_BaseClient);function PublicApiClient(){_classCallCheck(this,PublicApiClient);return _possibleConstructorReturn(this,(PublicApiClient.__proto__||Object.getPrototypeOf(PublicApiClient)).apply(this,arguments));}_createClass(PublicApiClient,[{key:'callPublicApi',value:function callPublicApi(




options,incidentId){
return _get(PublicApiClient.prototype.__proto__||Object.getPrototypeOf(PublicApiClient.prototype),'callHttpWithBearer',this).call(this,lodash.merge(options,{
headers:{
Accept:'application/json',
'Content-Type':'application/json; charset=utf-8'}},
{
uri:config.publicApiUrl+'/resources/incidents/'+incidentId}));

}},{key:'getIncident',value:function getIncident(

incidentId){
return this.callPublicApi({
method:'GET',
json:true},
incidentId).
then(BaseClient.validateHttpResponse());
}},{key:'resolveIncident',value:function resolveIncident(

incidentId){var comment=arguments.length>1&&arguments[1]!==undefined?arguments[1]:'The incident is now resolved';
return this.callPublicApi({
method:'POST',
json:{
resolved:true,
comments:comment}},

incidentId).
then(BaseClient.validateHttpResponse(204));
}},{key:'commentIncident',value:function commentIncident(

incidentId,comment){
return this.callPublicApi({
method:'POST',
json:{
comments:comment}},

incidentId).
then(BaseClient.validateHttpResponse(204));
}}],[{key:'callHealthUrl',value:function callHealthUrl()

{
return _get(PublicApiClient.__proto__||Object.getPrototypeOf(PublicApiClient),'callHealthUrl',this).call(this,config.publicApiUrl);
}},{key:'serviceName',get:function get(){return'public-api';}}]);return PublicApiClient;}(BaseClient);


PublicApiClient.untilWrapper();

return PublicApiClient;
};