'use strict';var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _get=function get(object,property,receiver){if(object===null)object=Function.prototype;var desc=Object.getOwnPropertyDescriptor(object,property);if(desc===undefined){var parent=Object.getPrototypeOf(object);if(parent===null){return undefined;}else{return get(parent,property,receiver);}}else if("value"in desc){return desc.value;}else{var getter=desc.get;if(getter===undefined){return undefined;}return getter.call(receiver);}};function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var request=require('../../core/request-wrapper');
var lodash=require('lodash');
var cookie=require('tough-cookie').Cookie;
var baseClientModule=require('../base-client');

function reduceCookiesBy(cookies,filterPredicate){
return cookies.reduce(function(result,item){
if(filterPredicate(item)){
result=item;// eslint-disable-line no-param-reassign
}
return result;
},null);
}

function extractDataFromCookie(cookiesHeader){
var cookies=lodash.isArray(cookiesHeader)?lodash.map(cookiesHeader,cookie.parse):cookie.parse(cookiesHeader);

if(!cookies||!cookies.length){
// bad or missing cookie header
return null;
}

var tokenCookie=reduceCookiesBy(cookies,function(item){return item.key.indexOf('to')===0;});

if(!tokenCookie){
return null;
}

var uidCookie=reduceCookiesBy(cookies,function(item){return item.key.indexOf('uid')===0;});

if(!uidCookie){
return null;
}

return{
token:tokenCookie.value,
uid:uidCookie.value};

}

module.exports=function(config,logger){
var BaseClient=baseClientModule(config,logger);var

WebApiClient=function(_BaseClient){_inherits(WebApiClient,_BaseClient);function WebApiClient(){_classCallCheck(this,WebApiClient);return _possibleConstructorReturn(this,(WebApiClient.__proto__||Object.getPrototypeOf(WebApiClient)).apply(this,arguments));}_createClass(WebApiClient,[{key:'callWebApi',value:function callWebApi(




method,subRoute,data){var overrides=arguments.length>3&&arguments[3]!==undefined?arguments[3]:{};
return _get(WebApiClient.prototype.__proto__||Object.getPrototypeOf(WebApiClient.prototype),'callHttpWithAccessToken',this).call(this,lodash.merge({
uri:config.webApiUrl+'/'+subRoute,
method:method,
json:data},
overrides));
}},{key:'createIntegration',value:function createIntegration(

sourceSystem,integrationName){
logger.info('creating integration '+integrationName+' of type '+sourceSystem+' for org \''+this.organization.name+'\'');

var data={
source_system_name:integrationName,
original_system_name:sourceSystem,
transport:'api'};


return this.callWebApi('POST','web/organization/integrations/multiple',data).
then(BaseClient.validateHttpResponse(201,function(errorBody){return errorBody.response.errors[0];})).
then(function(body){return body.item;});
}},{key:'signup',value:function signup(

organizationName,referrerEmail,referrerPassword,referrerName,featureToggles,state){
var data={
username:referrerEmail,
name:referrerName,
password:referrerPassword,
organization:organizationName};


if(featureToggles){
data.feature_toggles=featureToggles;
}
if(state){
data.state=state;
}
logger.info('signing up organization '+organizationName);

return this.callWebApi('POST','web/signup',data).then(BaseClient.validateHttpResponse(201)).then(function(body){return(
// The body returned from signup is actually the created user with some additions:
// organization_name and api_token (organization api token)
// In addition, to get the referrers access token and id we do a login request.
new WebApiClient({referrer:{token:body.item.api_token}}).
me().then(function(meResult){return{
displayName:organizationName,
name:body.item.organizationName,
id:body.item.organization,
apiToken:meResult.organization.api_token,
referrer:{
email:referrerEmail,
password:referrerPassword,
token:body.item.api_token,
id:body.item._id}};}));});



}},{key:'me',value:function me()

{
return this.callWebApi('GET','web/me',{}).
then(BaseClient.validateHttpResponse());
}},{key:'login',value:function login(

userEmail,userPassword){
return WebApiClient.login(userEmail,userPassword);
}},{key:'search',value:function search(

























BPQLSearchObject,environmentId){
var data=BPQLSearchObject;
if(environmentId){
data.environment_id=environmentId;
}
return this.callWebApi('web/search/incidents',data).
then(BaseClient.validateHttpResponse());
}},{key:'getIncident',value:function getIncident(

incidentId){
return this.callWebApi('GET','web/incidents/'+incidentId,{}).then(BaseClient.validateHttpResponse(201)).
then(function(body){return body.item;});
}},{key:'getIncidents',value:function getIncidents()

{var envId=arguments.length>0&&arguments[0]!==undefined?arguments[0]:'all';var folderId=arguments.length>1&&arguments[1]!==undefined?arguments[1]:'active';
return this.callWebApi('GET','web/incidents',{},{
qs:{
envId:envId,
folderId:folderId}}).

then(BaseClient.validateHttpResponse());
}},{key:'getEnvironment',value:function getEnvironment(

environmentId){
return this.callWebApi('GET','web/environments',{
qs:{
id:environmentId}}).

then(BaseClient.validateHttpResponse());
}},{key:'getEnvironments',value:function getEnvironments()

{
return this.callWebApi('GET','web/environments',{}).
then(BaseClient.validateHttpResponse());
}}],[{key:'login',value:function login(userEmail,userPassword){logger.info('login in user',userEmail);return request({method:'POST',uri:config.webApiUrl+'/login',json:{username:userEmail,password:userPassword}},logger).then(function(res){if(res.response.statusCode!==200){logger.error('Error loggin in ',res.body,res.response.statusCode);throw new Error(res.body);}logger.info('logged in user',userEmail);var userInfo=extractDataFromCookie(res.response.headers['set-cookie']);if(!userInfo){throw new Error('Error getting token and uid from cookies');}return userInfo;});}},{key:'callHealthUrl',value:function callHealthUrl()

{
return _get(WebApiClient.__proto__||Object.getPrototypeOf(WebApiClient),'callHealthUrl',this).call(this,config.webApiUrl);
}},{key:'serviceName',get:function get(){return'web-api';}}]);return WebApiClient;}(BaseClient);


WebApiClient.untilWrapper();

return WebApiClient;
};