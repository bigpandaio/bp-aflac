const _ = require('underscore');
const bpUtils = require('./bp-utils');

const MAX_DESC_LENGTH = 32700;
const MAX_TITLE_LENGTH = 280;

function createIncidentTitleInfo(incident) {
  if (!incident.alerts || incident.alerts.length === 0) {
    return null;
  }

  const incidentConfig = getIncidentConfig(incident);

  return {
    title: createTitleBasedOnProperty(incident, incidentConfig.primaryProperty),
    subTitle: createTitleBasedOnProperty(incident, incidentConfig.secondaryProperty),
    titleType: incidentConfig.primaryProperty,
    subTitleType: incidentConfig.secondaryProperty
  };
}

function createTitleBasedOnProperty(incident, property) {
  let propertyValues = [];

  incident.alerts.forEach(alert => {
    const tag = bpUtils.getAlertTagData(alert, property);
    propertyValues.push(tag);
  });

  propertyValues = bpUtils.uniqStrings(propertyValues);

  let title = propertyValues[0];

  if (propertyValues.length > 1) {
    title += ' and ' + (propertyValues.length - 1) + ' more';
  }

  return title;
}

function getIncidentConfig(incident) {
  const alert = incident.alerts[0];

  // Hack to overcome how nagios primary properties are getting sent.
  if (alert.sourceSystem.startsWith('nagios') || alert.sourceSystem.startsWith('icinga')) {
    return {
      primaryProperty: '_host',
      secondaryProperty: '_check'
    };
  }

  return {
    primaryProperty: alert.primaryProperty,
    secondaryProperty: alert.secondaryProperty
  }
}

function customizeTitle(config, incident, maxLength, titleInfo) {
  if (!maxLength) { maxLength = MAX_TITLE_LENGTH; }
  if (!titleInfo) { titleInfo = createIncidentTitleInfo(incident); }

  let title = '[BigPanda] ';

  const incidentTitle = titleInfo.title;
  const incidentSubtitle = titleInfo.subTitle;

  title += 'Incident ' + incidentTitle + (incidentSubtitle ? ' / ' + incidentSubtitle : '');

  if (title.length >= maxLength - 3) {
    title = title.substring(0, maxLength - 3) + "...";
  }

  return title;
}

function createIncidentDescription(config, incident) {
  const titleInfo = createIncidentTitleInfo(incident);

  if (!titleInfo) {
    return 'No alerts for incident: ' + incident.id + ' payload was: ' + JSON.stringify(incident);
  }

  return createAlertDetails(config, incident, titleInfo);
}

function createAlertDetails(config, incident, titleInfo) {
  if (config.alertDetailsFormat && config.alertDetailsFormat === 'json') {
    return createAlertDeatilsJson(incident);
  } else {
    return formatTable(config, incident, titleInfo);
  }
}

function createAlertDeatilsJson(incident) {
  const alerts = {
    alerts: _.map(incident.alerts, alert => {
      const newAlert = _.extend({}, alert);

      // Converting each alert tag value from [{ name: ... , value: ...}] to
      // a key value pair
      const alertKeyValues = _.reduce(alert.tags, (result, tag) => {
        result[tag.name] = tag.value;
        return result;
      }, {});

      newAlert.tags = alertKeyValues;

      return newAlert;
    })
  };

  return JSON.stringify(alerts);
}

function formatTable(config, incident, titleInfo) {
  const hasSubTitle = !!titleInfo.subTitleType;
  const alertsNum = incident.alerts.length;
  const sortedAlerts = bpUtils.sortIncidentAlerts(incident.alerts);

  let table = '';
  let tableLength = 0;
  let row = '';

  table += 'Alert Summary:\n' + calculateAlertsStatuses(incident.alerts) + '\n\n';
  tableLength += table.length;

  for (let i = 0; i < alertsNum; i++) {
    const alertData = formatAlertData(titleInfo, sortedAlerts[i]);

    row = customizeTableRow(config, alertData, titleInfo, hasSubTitle, i, alertsNum);

    if (table.length + row.length >= MAX_DESC_LENGTH) {
      table += `\n And ${alertsNum - i} more...`;
      break;
    }

    table += row;
    tableLength += row.length;
  }
  return table;
}

function formatInfoText(config, incident) {
  var muted = (incident.snooze && incident.snooze.snoozed) ? '*Incident is snoozed in BigPanda*\n' : '';
  var message = null;    // Missing data
  var generatedBy = '';  // Missing data

  var links = bpUtils.createLinks(config.BPHostLink, config.SYSTEM, incident, config.metadata);

  var linksStr = '';

  if (!config.flow.suppressPreviewLink) {
    linksStr += '* Go to the ' + bpUtils.formatLink('Incident Preview Page', links.landingPageUrl, "markdown") + '\n';
  }

  linksStr += '* Investigate in the ' + bpUtils.formatLink('BigPanda console', links.incidentUrl, "markdown") +
    '\n* See the ' + bpUtils.formatLink('Incident Timeline', links.timelineUrl, "markdown");

  return (message ? (message + '\n') : '') + muted + generatedBy + linksStr;
}

function calculateAlertsStatuses(alerts) {
  let statuses = {
    critical: 0,
    warning: 0,
    ok: 0
  };

  alerts.forEach(alert => {
    if (alert.status == 'Critical') { statuses.critical++; }
    else if (alert.status == 'Ok') { statuses.ok++; }
    else { statuses.warning++; }
  });

  return `${statuses.critical} Criticals, ${statuses.warning} Warnings, ${statuses.ok} Resolved`;
}

function formatAlertData(titleInfo, alertData) {
  alertData.primary = bpUtils.getAlertTagData(alertData, titleInfo.titleType);
  alertData.secondary = bpUtils.getAlertTagData(alertData, titleInfo.subTitleType);
  return alertData;
}

function customizeTableRow(config, alertData, titleInfo, hasSubTitle, alertNum, totalAlerts) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  const tz_offset = config.tz_offset || 0;
  let time = new Date(alertData.startedOn * 1000);

  time.setTime(time.getTime() + (time.getTimezoneOffset() + tz_offset * 60) * 60 * 1000); // Move to Current timezone
  const timeStr = time.toDateString('en-us', options) + ' ' + bpUtils.formatAMPM(time);

  const secondaryLine = hasSubTitle ? `\n${titleInfo.subTitleType}: ${alertData.secondary}` : '';
  const sourceStr = alertData.sourceSystem;

  // begin change to add fields from PDC and Viewpoint emails
  var extraFieldsStr = "";
  var extraFieldsInclude = []

  if ("tags" in alertData) {
    if (sourceStr === "api.pdc") {
      extraFieldsInclude = ["ClusterName", "CorrelationID", "GeneratedDateTime", "InitialAction", "KPIThreshold", "KPIValue", "LineInfo", "MsgID",
        "NotificationCategory", "OperatorInfo", "PDCURL", "ascode", "bp_priority", "pxObjClass", "pzInsKey"];

    } else if (sourceStr == "api.viewpoint") {
      extraFieldsInclude = ["alert_sender", "alert_subject", "application_name", "ascode", "bp_priority", "bp_status", "organization"]

    } else if (sourceStr == "thousandeyes.thousandeyes") {
      extraFieldsInclude = ["agentsInvolved", "alertId", "application_abbr", "application_name", "ascode", "environment", "link", "ruleExpression", 
    "ruleId", "service", "testId", "tier", "type", "url"]
    }
    for (var i = 0; i < alertData["tags"].length; i++) {
      var tagObj = alertData["tags"][i];

      if (extraFieldsInclude.includes(tagObj["name"])) {
        extraFieldsStr += tagObj["name"] + ": " + tagObj["value"] + "\n"
      }
    }

  } else {
    console.log("Tags not found in alert data.");
  }

  // console.log("extraFields: " + extraFieldsStr);

  if (!(extraFieldsStr === "")) {

    return `Alert ${alertNum + 1} of ${totalAlerts}
          Status: ${bpUtils.capitalizeFirstLetter(alertData.status)}
          ${titleInfo.titleType}: ${alertData.primary}${secondaryLine}
          ${extraFieldsStr}
          Description: ${(alertData.description || ' ')}
          Started At: ${timeStr}
          Source: ${alertData.sourceSystem}
          ------------------------------------------\n`;
  } else {
    return `Alert ${alertNum + 1} of ${totalAlerts}
          Status: ${bpUtils.capitalizeFirstLetter(alertData.status)}
          ${titleInfo.titleType}: ${alertData.primary}${secondaryLine}
          Description: ${(alertData.description || ' ')}
          Started At: ${timeStr}
          Source: ${alertData.sourceSystem}
          ------------------------------------------\n`;
  }
}

module.exports = {
  createIncidentTitleInfo: createIncidentTitleInfo,
  createTitleBasedOnProperty: createTitleBasedOnProperty,
  getIncidentConfig: getIncidentConfig,
  customizeTitle: customizeTitle,
  createIncidentDescription: createIncidentDescription,
  formatInfoText: formatInfoText
}
