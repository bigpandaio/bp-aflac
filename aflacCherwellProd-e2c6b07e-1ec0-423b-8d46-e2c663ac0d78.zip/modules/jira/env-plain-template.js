{
  "bp": {
    "authToken": ""
  }

  "jira": {
    "host": ".atlassian.net",
    "user": "",
    "password": "",
    "projectKey": "",
    "issueType": ""
  }
}
