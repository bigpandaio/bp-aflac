var bpUtils = require('../utils/bp-utils');

var AWS_REGION = "us-east-1";
var AWS = require('aws-sdk');
AWS.config.update({ region: AWS_REGION });
AWS.config.setPromisesDependency(require('bluebird'));

var SYSTEM = "ServiceNow";
var SQS = new AWS.SQS({region : 'us-east-1'});

module.exports = {
    createIncident: createIssueSQS,
    updateIncident: updateIssueSQS,
    setupContext: setupContext
};

function setupContext(context, incident, env, config, customerLogic, logicParams) {
}

function createIssueSQS(context, body, incident, callback) {
  // 1. Convert the fields into the required payload for SQS
  // 2. Call SQS to put the message
  var create_payload = {
      command: "createIssue",
      payload: { message: body },
      incidentId: incident.id
  };

  sendSQSMesage(context, create_payload, callback);
}

function updateIssueSQS(context, body, incident, issue, callback) {
  // 1. Create fields
  var update_payload = {
      command: "updateIssue",
      payload: { message: body }
  };

  var metaData = bpUtils.getMetadata(context);

  if (!metaData.autoShared) {
    update_payload.incidentId = incident.id; // This will indicate to the agent 
  }

  // 2. Call SQS
  sendSQSMesage(context, update_payload, callback);
}

function sendSQSMesage(context, msgPayload, callback){
  var queueName = process.env['queueName'];
  console.log('Sending following message payload to SQS');
  console.log(JSON.stringify(msgPayload));

  var params = {
    MessageBody: JSON.stringify(msgPayload),
    QueueUrl: queueName
  };

  SQS.sendMessage(params, function(err,data){
   if (err) {
     context.done(new Error(err + ""));
   } else {
     callback(null, data);  // SUCCESS
   }
  }); 
}
