
var bpUtils = require('modules/utils/bp-utils');

var PUSH_BASE_PATH = '/api/now/import/x_bip_panda_shareincident';
var BROWSE_API_PREFIX = '/nav_to.do?uri=incident.do?sys_id=';
var SYSTEM = 'ServiceNow';
var BASE_PUSH_REQ_OPS = {};

module.exports = {
    createIncident: createIssueAPI,
    updateIncident: updateIssueAPI,
    setupContext: setupContext
}


function setupContext(context, incident, env, config, customerLogic, logicParams) {
  context.bpContext.transport = createTransport(env, customerLogic, config);
}


function createTransport(env, customerLogic, config) {

  if (config.transport &&
      config.transport.protocol == "SOAP" &&
      customerLogic.soapPayloadTranslator) {

    return createSOAPTransport(config);

  } else {

    BASE_PUSH_REQ_OPS = {
      host: env.servicenow.host,
      port: 443,
      path: config.pushBasePath ||  PUSH_BASE_PATH,
      agent: false,
      auth: env.servicenow.user + ':' + env.servicenow.password,
      headers: {
          'Accept'      : 'application/json',
          'Content-Type': 'application/json'
      }
    };

    return createHTTPTransport(config);
  }
}

function createSOAPTransport(config) {
  const soapClient = require('./utils/bp-soap')(config.transport)();

  return {
    apiCall: soapAPICall
  }

  function soapAPICall(context, reqOpts, reqBody, system, action, expectedReturn, callback) {
    var customerLogic = bpUtils.getCustomerLogic(context);
    var soapRequest = customerLogic.soapPayloadTranslator(reqBody);

    soapClient.invokeSoap("insert", soapRequest).then(function(res) {
      var resultData = {};

      if (res && res.RESPONSE) {
        var match = res.RESPONSE.match(/(INC[^\s]+)/);

        if (match) {
            resultData.result = [{sys_id: match[0]}];
        }

        //https://vmntest.service-now.com/nav_to.do?uri=incident.do?sysparm_query=number=INC01799095
      }
      callback(resultData);
    });
  }
}

function createHTTPTransport(config) {
  return {
    apiCall: bpUtils.doApiCall
  }
}


function createIssueAPI(context, body, incident, callback) {
  var config = bpUtils.getConfig(context);
  var reqOpts = bpUtils.createRequestOptions(BASE_PUSH_REQ_OPS, 'POST', '');
  var logic = bpUtils.getCustomerLogic(context);

  context.bpContext.transport.apiCall(context, reqOpts, body, SYSTEM, 'creating issue', 201, function(err, data) {
    if (err) {
      return callback(err, data);
    }

    var key = data.result[0].sys_id;
    var incidentNo = data.result[0].display_value;
    var authToken = bpUtils.getAuthToken(context);

    if (!key) {
      var message = "Cannot create SNOW incident";

      if (data.result[0].status_message) {
        message += " - " + data.result[0].status_message;
      }

      return callback(message, data);
    }

    console.log("ServiceNow call result", data);

    var store = {};
    
    if (authToken) {
      store.authToken = authToken;
    }

    // Add more info to be store for next time this incident is called 
    if (logic.cacheStoreExtraValues) {
      logic.cacheStoreExtraValues(context, incident, store);
    }

    // Move to the API track
    bpUtils.storeIncidentData(context, SYSTEM, incident.id, incident.status, key, store, function(err, data) {

      if (err) {
        return callback(err);
      }

      var env = bpUtils.getEnv(context);
      var issueLink = createRemoteLink(env, key);

      bpUtils.updateBigPandaIncident(context, {}, incidentNo, incident.id, issueLink, function(err,data) {
         if (err) {
             callback(err);
         }
         callback(null,{"servicenowSysId" : key});
      });
    });
  });
}

function createRemoteLink(env, key) {
  var host = env.servicenow.internalHost || env.servicenow.host;
  return "https://" + host + BROWSE_API_PREFIX + key;
}

function updateIssueAPI(context, body, incident, issue, callback) {
  var config = bpUtils.getConfig(context);
  var reqOpts = bpUtils.createRequestOptions(BASE_PUSH_REQ_OPS, 'POST', '');
  var logic = bpUtils.getCustomerLogic(context);

  // Move to the API track
  context.bpContext.transport.apiCall(context, reqOpts, body, SYSTEM, 'updating issue', 201, function(err, data) {
    if (err) {
      callback(err);
    }

    var authToken = bpUtils.getAuthToken(context);

    var store = issue || {};
    
    if (authToken) {
      store.authToken = authToken;
    }

    // Add more info to be store for next time this incident is called 
    if (logic.cacheStoreExtraValues) {
      logic.cacheStoreExtraValues(context, incident, store);
    }

    bpUtils.storeIncidentData(context, SYSTEM, incident.id, incident.status, issue.ticket_key, store, function(err) {
        if (err) {
            callback(err);
        }
        callback(null,data);
    });
  });
}
