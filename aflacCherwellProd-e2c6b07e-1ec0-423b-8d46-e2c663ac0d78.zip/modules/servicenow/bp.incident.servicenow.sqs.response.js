var bpUtils = require('../utils/bp-utils');
var AWS_REGION = "us-east-1";
var AWS = require('aws-sdk');
var SQS = new AWS.SQS({region : 'us-east-1'});
var BROWSE_API_PREFIX = '/nav_to.do?uri=incident.do?sys_id=';

exports.handle = handle;

function handle(event, context, env, CONFIG, callback){
  setupContext(context, env, CONFIG)
  console.log('Received following message payload from servicenow')
  console.log(JSON.stringify(event));

  // Auth token should be taken from the env.
  var authToken = getAuthToken(env);
  var queueName = process.env['queueName'];
  var incidentId = event.bp_incident_id;
  var errors = event.body.error;
  
  var SYSTEM = 'ServiceNow';

  if (!incidentId) {
    console.error("No incident available - ack");
    ackMessage();

  } else {

    if (!event.body || !event.body.result || !event.body.result[0]) {
      console.error("Invalid response body");
      return ackMessage();
    } 

    var snowResponse = event.body.result[0];
    var snowSysId = snowResponse.sys_id;
    var snowIncidentId = snowResponse.display_value;

    if (!snowSysId) {
      var errorMessage = snowResponse.status_message || snowResponse.error_message;

      bpUtils.extractIssueData(context, SYSTEM, incidentId, function (err, issue) {

        if (!issue || !issue.reportedFailError) {
          bpUtils.storeIncidentKeyMapping(context, SYSTEM, incidentId, null, {reportedFailError: true}, function() {
            bpUtils.updateBigPandaIncident(context, {}, SYSTEM, incidentId, errorMessage, rollbackMessage);
          });
        } else {
          console.log("Error was already sent - not sending again");
          ackMessage();
        }
      });
      

    } else {

      bpUtils.storeIncidentKeyMapping(context, SYSTEM, incidentId, snowSysId, authToken, function() {
        var issueLink = null;
        var nextStep = null;

        if (errors != null && errors != '') {
          issueLink = 'Error return from ServiceNow Agent execution:' + JSON.stringify(errors);
          nextStep = rollbackMessage;
        } else if (snowResponse.status == "inserted") {
          issueLink = createRemoteLink(env, snowSysId);
          nextStep = ackMessage;
        }

        if (issueLink) {
          console.log("Adding issue link", issueLink);

          bpUtils.updateBigPandaIncident(context, {}, snowIncidentId, incidentId, issueLink, ackMessage);
        } else {
          console.log("Update - No need to add a comment in BP");
          ackMessage();
        }
      });
    }
  }

  function createRemoteLink(env, key) {
    var host = process.env['linkedHost'];
    return "https://" + host + BROWSE_API_PREFIX + key;
  }

  function ackMessage() {
    var params = {
      ReceiptHandle: event.receiptHandle,
      QueueUrl: queueName
    };

    SQS.deleteMessage(params, function (err, data) {
        console.log('Execution completed successfully.');
        
        callback(err, data);
    });
  }

  function rollbackMessage() {
    var params = {
      ReceiptHandle: event.receiptHandle,
      QueueUrl: queueName,
      VisibilityTimeout: 0
    };

    SQS.changeMessageVisibility(params, function (err, data) {
        console.log('Execution completed by rolling back message.');
    
        callback(err, data);
    });
  }
}

function setupContext(context, env, config) {
  context.bpContext = {
    env: env,
    config: config
  };
}

function getAuthToken(env) {
  return env.bp ? env.bp.authToken : null;
}