const request = require('request').defaults({jar: true});
const bpUtils = require('./utils/bp-utils');

const SYSTEM = 'Cherwell';

function loginCherwell(url, host, userId, password) {
  return new Promise((resolve, reject) => {
    const soapEnvelope =
        `<?xml version="1.0" encoding="utf-8"?>
         <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
           <soap12:Body>
             <Login xmlns="http://cherwellsoftware.com">
               <userId>${userId}</userId>
               <password>${password}</password>
             </Login>
           </soap12:Body>
         </soap12:Envelope>`;

    request.post({
      headers: {
        Host: host,
        'Content-Type': 'text/xml'
      },
      url: url,
      body: soapEnvelope,
    }, function(err, response, resBody){
      if (err) { reject(err); }
      else if (response.statusCode === 200 && !resBody.includes('<LoginResult>false</LoginResult>')) {
        console.log('Logged In as ' + userId);
        console.log(resBody);
        resolve(true);
      } else {
        console.log('Failed to Authenticate:');
        console.log('Status ' + response.statusCode);
        console.log(resBody);
        reject('Invalid Credentials');
      }
    });
  });
}

function loginCherwellRestApi(url, userId, password, client_id) {
  return new Promise((resolve, reject) => {
    const authObject = {
      grant_type: 'password',
      client_id: client_id,
      username: userId,
      password: password,
      auth_mode: 'internal'
    }

    let authString = '';
    Object.keys(authObject).forEach(key => {
    	if(authString.length > 0) { authString += '&'}
    	authString += key + '=' + encodeURIComponent(authObject[key]);
    });

    request.post({
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      url: url + '/token',
      body: authString,
    }, (err, response, resBody) => {
      if (err) { reject(err); }
      else if (response.statusCode === 200 && resBody) {
        try { JSON.parse(resBody).access_token; }
        catch (e) { return reject('Invalid Auth'); }
        resolve(JSON.parse(resBody).access_token);
      } else {
        console.log('Failed to Authenticate:');
        console.log('Status ' + response.statusCode);
        console.log(resBody);
        reject('Invalid Credentials');
      }
    });
  });
}

function submitIncident(incident, context, url, host) {
  return new Promise((resolve, reject) => {
    bpUtils.getDynamoData(context.bpContext.config.dynamoTable, { incident_id: context.bpContext.incidentId }, (err, storedMapping) => {
      if (err) {
        reject(err);
      } else if (storedMapping) {
        console.log('Incident found in cache:');
        console.log(storedMapping);
        console.log('Ignoring: incident already shared');
        resolve(false);
      } else {
        const soapEnvelope =
            `<?xml version="1.0" encoding="utf-8"?>
             <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
               <soap12:Body>
                 <CreateBusinessObject xmlns="http://cherwellsoftware.com">
                   <busObNameOrId>Incident</busObNameOrId>
                   <creationXml>${incident}</creationXml>
                 </CreateBusinessObject>
               </soap12:Body>
             </soap12:Envelope>`;

        console.log('Submitting Soap Request:');
        console.log(soapEnvelope);
        request.post({
          headers: {
            Host: host,
            'Content-Type': 'text/xml'
          },
          url: url,
          body: soapEnvelope,
        }, function(err, response, resBody) {
          if (err) { reject(err); }
          else if (response.statusCode === 200 && !resBody.includes('<CreateBusinessObjectResult />') && resBody.match(/<CreateBusinessObjectResult>.*<\/CreateBusinessObjectResult>/)) {
            console.log('Cherwell Incident created:');
            console.log(resBody);
            const recId = resBody.match(/<CreateBusinessObjectResult>(.*)<\/CreateBusinessObjectResult>/)[1];
            const cacheItem = {
              incident_id: context.bpContext.incidentId,
              ticket_key: recId,
              timestamp: Date.now()
            }

            bpUtils.storeDynamoData(context.bpContext.config.dynamoTable, cacheItem, (err, storedData) => {
              if (err) {
                console.log('Failed to update incident cache:');
                console.log(err);
              } else {
                console.log('Updated incident cache:');
                console.log(storedData);
              }
              resolve(recId);
            });
          } else {
            console.log('Failed to create Cherwell Incident:');
            console.log('Status ' + response.statusCode);
            console.log(resBody);
            reject('Invalid Request');
          }
        });
      }
    });
  });
}

function submitIncidentRestApi(incident, context, url, token) {
  return new Promise((resolve, reject) => {
    bpUtils.getDynamoData(context.bpContext.config.dynamoTable, { incident_id: context.bpContext.incidentId }, (err, storedMapping) => {
      if (err) {
        reject(err);
      } else if (storedMapping) {
        console.log('Incident found in cache:');
        console.log(storedMapping);
        console.log('Ignoring: incident already shared');
        resolve(false);
      } else {
        console.log('Submitting Incident Request:');
        console.log(incident);
        request.post({
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + token
          },
          url: url + '/api/V1/savebusinessobject',
          body: JSON.stringify(incident),
        }, (err, response, resBody) => {
          if (err) { reject(err); }
          else if (response.statusCode === 200) {
            console.log('Cherwell Incident created:');
            console.log(resBody);
            try { JSON.parse(resBody).busObRecId; }
            catch (e) { return reject('Invalid Request'); }
            const cacheItem = {
              incident_id: context.bpContext.incidentId,
              ticket_key: JSON.parse(resBody).busObRecId,
              timestamp: Date.now()
            }

            bpUtils.storeDynamoData(context.bpContext.config.dynamoTable, cacheItem, (err, storedData) => {
              if (err) {
                console.log('Failed to update incident cache:');
                console.log(err);
              } else {
                console.log('Updated incident cache:');
                console.log(storedData);
              }
              resolve(JSON.parse(resBody));
            });
          } else {
            console.log('Failed to create Cherwell Incident:');
            console.log('Status ' + response.statusCode);
            console.log(resBody);
            reject(resBody);
          }
        });
      }
    });
  });
}

function updateBigPanda(context, recId, publicId) {
  return new Promise((resolve, reject) => {
    const incidentId = context.bpContext.incidentId;
    const issueLink = context.bpContext.config.cherwell.incidentUrl + recId;
    const comment = (publicId) ? SYSTEM + ' Incident ' + publicId : SYSTEM;

    if (!recId) { return resolve(false); }

    console.log('Updating BigPanda Incident with link: ' + issueLink);
    bpUtils.updateBigPandaIncident(context, {}, comment, incidentId, issueLink, () => resolve(true));
  });
}

exports.handler = function (incident, context, config, callback) {
  if (config.cherwell.restApi) {
    loginCherwellRestApi(config.cherwell.url, config.cherwell.userId, config.cherwell.password, config.cherwell.clientId)
    .then(token => submitIncidentRestApi(incident, context, config.cherwell.url, token))
    .then(response => updateBigPanda(context, response.busObRecId, response.busObPublicId))
    .then(() => callback(null, {statusCode: 200}))
    .catch(callback);
  } else {
    loginCherwell(config.cherwell.url, config.cherwell.host, config.cherwell.userId, config.cherwell.password)
    .then(() => submitIncident(incident, context, config.cherwell.url, config.cherwell.host))
    .then(recId => updateBigPanda(context, recId))
    .then(() => callback(null, {statusCode: 200}))
    .catch(callback);
  }
}
