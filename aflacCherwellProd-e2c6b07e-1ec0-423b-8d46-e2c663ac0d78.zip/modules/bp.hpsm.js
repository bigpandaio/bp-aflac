const request = require('request');
const bpUtils = require('modules/utils/bp-utils');
const SYSTEM = 'HP Service Manager';

function checkCache(context) {
  return new Promise((resolve, reject) => {
    bpUtils.getDynamoData(context.bpContext.config.dynamoTable, { incident_id: context.bpContext.incident.id }, (err, storedMapping) => {
      if (err) {
        console.log('Unable to connect to cache:');
        return reject(err);
      } else if (!storedMapping) {
        // No corresponding item found in cache
        if (context.bpContext.incident.resolved) {
          console.log('Ignoring - Incident already resolved');
          context.SOAPAction = 'SKIP';
        } else {
          console.log('Creating New Ticket');
          context.SOAPAction = 'Create';
          context.SOAPData = context.bpContext.soapXml.create;
        }
      } else {
        console.log('Incident found in cache:');
        console.log(JSON.stringify(storedMapping));

        if (storedMapping.status === 'Ok') {
          console.log('Ignoring - Ticket already resolved');
          context.SOAPAction = 'SKIP';
        } else if (context.bpContext.incident.status === 'Ok' && context.bpContext.config.hpsm.submitResolve) {
          console.log('Resolving Ticket');
          context.SOAPAction = 'Resolve';
          context.SOAPData = context.bpContext.soapXml.resolve;
          return resolve(storedMapping);
        } else if (context.bpContext.config.hpsm.submitUpdate) {
          console.log('Updating Ticket');
          context.SOAPAction = 'Update';
          context.SOAPData = context.bpContext.soapXml.update;
          return resolve(storedMapping);
        } else {
          console.log('Ignoring - Update or Resolve not enabled');
          context.SOAPAction = 'SKIP';
        }
      }

      // SOAPAction - SKIP or Create - no data to pass
      resolve(true);
    });
  });
}

function submitRequest(cacheItem, context) {
  return new Promise((resolve, reject) => {
    if (context.SOAPAction === 'SKIP') { return resolve(true); }
    const ticketId = (context.SOAPAction !== 'Create') ? cacheItem.hpsm_id : '';
    const soapEnvelope =
      `<?xml version="1.0" encoding="utf-8"?>
       <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:pws="http://servicecenter.peregrine.com/PWS" xmlns:com="http://servicecenter.peregrine.com/PWS/Common">
         <soapenv:Header>${context.bpContext.config.hpsm.customHeader}</soapenv:Header>
         <soapenv:Body>
           <pws:${context.SOAPAction}IncidentRequest ignoreEmptyElements="true" updateconstraint="-1">
             <pws:model>
               <pws:keys><pws:IncidentID>${ticketId}</pws:IncidentID></pws:keys>
               <pws:instance>${context.SOAPData}</pws:instance>
             </pws:model>
           </pws:${context.SOAPAction}IncidentRequest>
         </soapenv:Body>
       </soapenv:Envelope>`;

    console.log('Submitting Soap Request to: ' + context.bpContext.config.hpsm.url);
    console.log(soapEnvelope);
    request.post({
      auth: {
        username: context.bpContext.config.hpsm.username,
        password: context.bpContext.config.hpsm.password
      },
      headers: {
        'Content-Type': 'text/xml',
        SOAPAction: context.SOAPAction
      },
      url: context.bpContext.config.hpsm.url,
      body: soapEnvelope,
    }, (err, response, resBody) => {
      if (err) { reject(err); }
      else if (!isValidResponse(response, resBody)) {
        console.log('Failed to create Service Manager Incident:');
        console.log('Status ' + response.statusCode);
        console.log(resBody);
        reject('Request Failed');
      } else {
        console.log('HPSM Incident ' + context.SOAPAction + 'd:');
        console.log(resBody);
        const recId = resBody.match(/<IncidentID type="String">(IM\d+)<\/IncidentID>/)[1];

        if (context.SOAPAction === 'Create') {
          cacheItem = {
            incident_id: context.bpContext.incident.id,
            hpsm_id: recId,
            created_time: Math.floor(Date.now() / 1000)
          }
        }

        if (context.SOAPAction === 'Resolve') {
          cacheItem.resolved_time = Math.floor(Date.now() / 1000);
        }

        cacheItem.last_updated_time = Math.floor(Date.now() / 1000);
        cacheItem.status = context.bpContext.incident.status;

        bpUtils.storeDynamoData(context.bpContext.config.dynamoTable, cacheItem, (err, storedData) => {
          if (err) {
            console.log('Failed to update incident cache:');
            console.log(err);
          } else {
            console.log('Updated incident cache:');
            console.log(storedData);
          }
          resolve(cacheItem.hpsm_id);
        });
      }
    });
  });
}

function isValidResponse(response, resBody) {
  return (response.statusCode === 200
          && resBody.includes('IncidentResponse message="Success"')
          && resBody.match(/<IncidentID type="String">IM\d+<\/IncidentID>/));
}

function updateBigPanda(recId, context) {
  return new Promise((resolve, reject) => {
    if (context.SOAPAction !== 'Create' || !recId) { return resolve(true); }

    const issueLink = context.bpContext.config.hpsm.incidentUrl + '%22' + recId + '%22';
    console.log('Updating BigPanda Incident with link: ' + issueLink);
    bpUtils.updateBigPandaIncident(context, {}, SYSTEM, context.bpContext.incident.id, issueLink, () => resolve(true));
  });
}

exports.handler = function (context, callback) {
  checkCache(context)
  .then(cacheItem => submitRequest(cacheItem, context))
  .then(recId => updateBigPanda(recId, context))
  .then(() => callback(null, {statusCode: 200}))
  .catch(callback);
}
