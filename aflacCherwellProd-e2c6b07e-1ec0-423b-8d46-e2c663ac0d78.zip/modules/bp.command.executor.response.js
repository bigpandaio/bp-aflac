const bpUtils = require('./utils/bp-utils');
const AWS = require('aws-sdk');
const SQS = new AWS.SQS({region : 'us-east-1'});

exports.handler = function (event, context, env, config, callback){
  const queueUrl = config.sqs.queueUrl;

  console.log('Received following message payload from spectrum:')
  console.log(event);
  ackMessage();

  function ackMessage() {
    var params = {
      ReceiptHandle: event.receiptHandle,
      QueueUrl: queueUrl
    };

    SQS.deleteMessage(params, data => {
        console.log('Execution completed successfully.');
        if (data) { console.log(data); }
        callback(null, {statusCode: 200});
    });
  }
}
