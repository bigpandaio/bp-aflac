
// Constants

var MAX_DESC_LENGTH = 32700;
var MAX_TITLE_LENGTH = 250;

var SYSTEM = 'ServiceNow';
var DB_SYSTEM = SYSTEM;

var PUSH_BASE_PATH = '/api/now/import/x_bip_panda_shareincident';
var BROWSE_API_PREFIX = '/nav_to.do?uri=incident.do?sys_id=';

var BASE_PUSH_REQ_OPS = {};
var BP_HOST_LINK = "a.bigpanda.io";

var CREATED_ACTION = 'created';
var UPDATED_ACTION = 'updated';

var RETRY_CREATE_DURATION = 8 * 1000;
var MAX_CREATE_RETRIES = 3;

// Init

// Modules
var bpUtils = require('./utils/bp-utils');
var _ = require('underscore');
var moment = require('moment-timezone');
var flowLogicSQS = require('./servicenow/bp.incident.to.servicenow.sqs.flow.logic');
var flowLogicAPI = require('./servicenow/bp.incident.to.servicenow.api.flow.logic');

// Localization

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
//process.env.TZ = 'America/New_York';

function setupContext(context, incident, env, config, customerLogic, metadata, logicParams) {
  context.bpContext = {
    env: env,
    config: config,
    customerLogic: customerLogic,
    logicParams: logicParams,
    metadata: metadata,
    flowLogic: createFlowLogic(env, customerLogic, config)
  };

  config.BPHostLink = BP_HOST_LINK;

  var bpHostPrefix = bpUtils.getFlags(context).bpHostPrefix;

  if (bpHostPrefix) {
    config.BPHostLink = bpHostPrefix + "-" + BP_HOST_LINK;
  }

  // Keep the authToken only if requested to save it.
  // This should ONLY be used in the demo.
  // if this gets real, we can easily encrypt the token with our KMS key
  if (logicParams && logicParams.authToken) {
    console.log("Saving auth token");
    context.bpContext.overrideAuthToken = logicParams.authToken;
  }

  context.bpContext.flowLogic.setupContext(context,
    incident,
    env,
    config,
    customerLogic,
    logicParams);

  config.flow = config.flow || {} // null pattern in case no flow

  return;

  function createFlowLogic(env, customerLogic, config) {
    if (config.flowLogic && config.flowLogic.type == "SQS") {
      return flowLogicSQS;
    } else {
      return flowLogicAPI;
    }
  }
}

// Formating customizatoins

function customizeTableRow(context, alertData, titleInfo, hasSubTitle, alertNum, totalAlerts) {
    const config = bpUtils.getConfig(context);
    const customerLogic = bpUtils.getCustomerLogic(context);

    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    const formatString = 'ddd MMM DD YYYY h:mm A';
    var time, timeStr;

    if (config.timezone.region) {
      time = moment(alertData.startedOn * 1000);
      timeStr = time.tz(config.timezone.region).format(formatString);
    } else {
      time = new Date(alertData.startedOn * 1000);
      time.setTime(time.getTime() + (time.getTimezoneOffset() + config.timezone.offset * 60) *60*1000); // Move to Current timezone
      timeStr = time.toDateString("en-us", options) + " " + bpUtils.formatAMPM(time);
    }

    var secondaryLine = hasSubTitle ? `\n${titleInfo.subTitleType}: ${alertData.secondary}` : '';
    var sourceStr = alertData.sourceSystem;

    var appendString = '';
    if (customerLogic.customAppendToDescription) {
      appendString = customerLogic.customAppendToDescription(context, alertData);
    }

    return `Alert ${alertNum + 1} of ${totalAlerts} \n` +
           `Status: ${bpUtils.capitalizeFirstLetter(alertData.status)} \n` +
           `${titleInfo.titleType}: ${alertData.primary}${secondaryLine} \n` +
           `Description: ${(alertData.description || ' ')} \n${appendString}` +
           `Started At: ${timeStr} \n` +
           `Source: ${alertData.sourceSystem} \n` +
           `------------------------------------------\n`;
}

function customizeTitle(config, incident, titleInfo) {
  var incidentTitle = titleInfo.title;
  var incidentSubtitle = titleInfo.subTitle;

  var title = incidentTitle + " - " + (incidentSubtitle ? ' / ' + incidentSubtitle : '');

  if (title.length >= MAX_TITLE_LENGTH - 3) {
    title = title.substring(0, MAX_TITLE_LENGTH - 3) + "...";
  }

  return title;
}


// ---------------------------  GENERIC FORMATING    ---------------------------

function createFields(context, incident, issue, action, callback) {
    var lastStatus = (issue) ? issue.last_status : null;
    var titleInfo = createIncidentTitleInfo(incident);
    var config = bpUtils.getConfig(context);
    var shareMetadata = bpUtils.getMetadata(context);
    var customerLogic = bpUtils.getCustomerLogic(context);

    if (!titleInfo) {

      if (action === CREATED_ACTION) {
        callback("No alerts for incident: " + incident.id + " payload was: " + JSON.stringify(incident));
        return;
      } else {

        // This will probably only happen on merge
        let fields = {
          u_bp_incident_status: "ok",
          u_bp_alerts_statuses: "0 Criticals, 0 Warnings, 0 Resolved",
          u_bp_alerts_count: 0,
          u_bp_incident_id: incident.id,
          u_bp_alert_details: "Alert Summary:\n0 Criticals, 0 Warnings, 0 Resolved\n\n"
        };

        if (customerLogic.customFieldsUpdateOnly) {
          customerLogic.customFieldsUpdateOnly(context, incident, fields);
        }

        return fields;
      }
    }

    var links = bpUtils.createLinks(config.BPHostLink, SYSTEM, incident, shareMetadata);

    var activeAlertsCount = _.countBy(incident.alerts, function(alert) {
      return alert.active;
    });

    var fields = {
      u_bp_incident_start: incident.startedOn,
      u_bp_primary_objects: bpUtils.getAlertTagsData(incident, titleInfo.titleType),
      u_bp_primary_object_type: titleInfo.titleType,
      u_bp_secondary_objects: bpUtils.getAlertTagsData(incident, titleInfo.subTitleType),
      u_bp_secondary_object_type: titleInfo.subTitleType,

      u_bp_alerts_statuses: calculateAlertsStatuses(incident.alerts),
      u_bp_alerts_count: incident.alerts && incident.alerts.length,
      u_bp_active_alerts_count: activeAlertsCount.true,

      u_bp_environment: shareMetadata.environment,
      u_bp_incident_id: incident.id,

      u_bp_alert_details: createAlertDetails(context, incident, titleInfo),
      updatedTime: moment().unix()
    }

    var incidentStatus = calculateIncidentStatus(context, incident, issue);

    // Making sure the status only present when is there (it won't be there for no AutoResolve)
    if (incidentStatus != null) {
      fields.u_bp_incident_status = incidentStatus;
    }

    if (shareMetadata.comment) {
      var commentedUser = "";

      if (shareMetadata.commentedByName) {
        commentedUser = shareMetadata.commentedByName + ": ";
      }

      fields.u_bp_new_comment = commentedUser + shareMetadata.comment;
      fields.comments = commentedUser + shareMetadata.comment;
    }

    if (incident.status != lastStatus && config.flow && config.flow.includeLastStatusChange) {
        fields.u_bp_status_change = incident.status;
    }

    // Check if we only need to send BP details on update.
    if (action === UPDATED_ACTION && config.flow && config.flow.onlyDetailsOnUpdate) {      
      if (customerLogic.customFieldsUpdateOnly) {
        customerLogic.customFieldsUpdateOnly(context, incident, fields);
      }
      return fields;
    }

    fields.short_description = customizeTitle(config, incident, titleInfo);

    additionalFieldsUpdate(context, config, incident, fields);

    if (customerLogic.customFieldsUpdate) {
      customerLogic.customFieldsUpdate(context, incident, fields);
    }

    if (action === CREATED_ACTION) {
      // TODO make this customizable per customer
      fields.comments = formatInfoText(config, shareMetadata, incident);

      fields.u_bp_auto_shared = shareMetadata.autoShared;

      fields.u_bp_preview_url = links.landingPageUrl;
      fields.u_bp_incident_url = links.incidentUrl;
      fields.u_bp_timeline_url = links.timelineUrl;

      if (config.servicenow && config.servicenow.reportedByField) {
        fields[config.servicenow.reportedByField] = shareMetadata.reportedBy;
      }

      if (customerLogic.setPrimaryAlertFields) {
        customerLogic.setPrimaryAlertFields(context, incident, fields);
      }
    }

    return fields;
}

function createAlertDetails(context, incident, titleInfo) {
  const config = bpUtils.getConfig(context);
  if (config.alertDetailsFormat && config.alertDetailsFormat == "json") {
    return createAlertDeatilsJson(config, incident, titleInfo);
  } else {
    return formatTable(context, incident, titleInfo)
  }
}

function additionalFieldsUpdate(context, config, incident, fields) {
  var logicParams = context.bpContext.logicParams;

  if (logicParams && logicParams.fields) {
    logicParams.fields.forEach(function(field) {
      fields[field.targetName] = bpUtils.getAlertTagsData(incident, field.sourceName);
    });
  }
}

function formatInfoText(config, shareMetadata, incident) {
  var muted = (incident.snooze && incident.snooze.snoozed) ? '*Incident is snoozed in BigPanda*\n' : '';
  var message = shareMetadata.intialMessage || '';
  var generatedBy = null;

  if (shareMetadata.reportedBy) {
    generatedBy = 'Incident was manually shared by ' + shareMetadata.reportedBy
  } else {
    generatedBy = 'Incident was shared from BigPanda';
  }


  var links = bpUtils.createLinks(config.BPHostLink, SYSTEM, incident, shareMetadata);

  var linksStr = '* Go to the [code]' + bpUtils.formatLink('Incident Preview Page', links.landingPageUrl) + "[/code]\n" +
      '* Investigate in the [code]' + bpUtils.formatLink('BigPanda console', links.incidentUrl) + "[/code]\n" +
      '* See the [code]' + bpUtils.formatLink('Incident Timeline', links.timelineUrl) + "[/code]";

  return (generatedBy ? (generatedBy) : '') +
         (message ? (' with message: ' + message) : '') +
         "\n\n\n" +
         muted +
         linksStr;
}

function createAlertDeatilsJson(config, incident, titleInfo) {
  var alerts = {
    alerts: _.map(incident.alerts, function(alert) {
      var newAlert = _.extend({}, alert);

      // Converting each alert tag values from [{ name: ... , value: ...}] to
      // // a key value pair
      var alertKeyValues = _.reduce(alert.tags, function(result, tag) {
        result[tag.name] = tag.value;

        return result;
      }, {});

      newAlert.tags = alertKeyValues;

      return newAlert;
    })
  }

  return JSON.stringify(alerts);
}

function formatTable(context, incident, titleInfo, maxTableLength) {
  var hasSubTitle = !!titleInfo.subTitleType;

  var table = "";
  var sortedAlerts = bpUtils.sortIncidentAlerts(incident.alerts);

  var alertsNum = incident.alerts.length;
  var tableLength = 0;
  var row = "";

  table += "Alert Summary:\n" + calculateAlertsStatuses(incident.alerts) + "\n\n";
  tableLength += table.length;

  for (var i = 0; i < alertsNum; i++) {
    var alertData = formatAlertData(titleInfo, sortedAlerts[i]);

    row = customizeTableRow(context, alertData, titleInfo, hasSubTitle, i, alertsNum);

    if ((table.length + row.length) >= maxTableLength) {
        table += `\n And ${alertsNum - i} more...`;
        break;
    }

    table += row;
    tableLength += row.length;
  }

  return table;
}

function createIncidentTitleInfo(incident) {
    if (!incident.alerts || incident.alerts.length === 0) {
      return null;
    }

    var incidentConfig = bpUtils.getIncidentConfig(incident);

    return {
        title: createTitleBasedOnProperty(incident, incidentConfig.primaryProperty),
        subTitle: createTitleBasedOnProperty(incident, incidentConfig.secondaryProperty),
        titleType: incidentConfig.primaryProperty,
        subTitleType: incidentConfig.secondaryProperty
    };
}

function formatAlertData(titleInfo, alertData) {
    alertData.primary = bpUtils.getAlertTagData(alertData, titleInfo.titleType);
    alertData.secondary = bpUtils.getAlertTagData(alertData, titleInfo.subTitleType);
    return alertData;
}

function createTitleBasedOnProperty(incident, property) {
    var propertyValues = [];

    incident.alerts.forEach(function (alert) {
        var tag = bpUtils.getAlertTagData(alert, property);
        propertyValues.push(tag);
    });

    propertyValues = bpUtils.uniqStrings(propertyValues);

    var title = propertyValues[0];

    if (propertyValues.length > 1) {
        title += " and " + (propertyValues.length - 1) + " more";
    }

    return title;
}

function calculateIncidentStatus(context, incident, issue) {
  var customerLogic = bpUtils.getCustomerLogic(context);

  var noAutoResolve = customerLogic.noAutoResolve && customerLogic.noAutoResolve(context, incident, issue);

  if (incident.status == "Ok" && noAutoResolve) {
    console.log("No Auto Resolve");
    return null;
  } else {
    return incident.status && incident.status.toLowerCase();
  }
}

function calculateAlertsStatuses(alerts) {
  var statuses = {
    critical: 0,
    warning: 0,
    ok: 0
  };

  alerts.forEach(function(alert) {
    if (alert.status == 'Critical') {
      statuses.critical++;
    }

    else if (alert.status == 'Ok') {
      statuses.ok++;
    }

    else {
      statuses.warning++;
    }
  });

  return `${statuses.critical} Criticals, ${statuses.warning} Warnings, ${statuses.ok} Resolved`;
}


// --------------------------- GENERIC FLOW ---------------------------


// Main Flow

exports.handle = handle;

function handle(event, context, env, customerLogic, config, logicParams, callback) {
  try {
    var incident = event.incident;
    incident.links = event.links; // Make it easier to access later on

    var metadata = null;

    // Parsing the reporterBy to be the data we receive from the metadata.
    if (event.metadata) {
      metadata = bpUtils.extractMetadata(event.metadata);

      console.log("Setting metadata for incident", metadata);
    }

    setupContext(context, incident, env, config, customerLogic, metadata, logicParams);

    var shareMetadata = bpUtils.getMetadata(context);

    if (shareMetadata.externalComment) {
      return finished(null, "ignoring machine generated comment update");
    }

    handleIncidentLogic();

  } catch(err) {
    finished(err);
  }

  function finished(err, data) {
    var errPayload = null;

    if (err) {
      console.log("returning error: " + err);
      return callback(JSON.stringify({status: 400, error: err + ""}));
    }

    console.log('Execution completed successfully.');

    if (data) {
        console.log(data);
    }

    callback(null, data);
  }

  function handleIncidentLogic(retryCounter) {
    var customerLogic = bpUtils.getCustomerLogic(context);
    retryCounter = retryCounter || 1;

    if (retryCounter > MAX_CREATE_RETRIES) {
      console.log("No updates - Max retries");
      return finished(null, null); // Ignore
    }

    bpUtils.extractIssueData(context, SYSTEM, incident.id, function (err, issue) {
      if (err) {
        return finished(err);
      }

      if (issue && customerLogic.updateContextFromCache) {
        customerLogic.updateContextFromCache(context, incident, issue);
      }

      executeIncidentFlow(issue, retryCounter);
    });
  }

  function executeIncidentFlow(issue, retryCounter) {
    var customerLogic = bpUtils.getCustomerLogic(context);
    var checkShouldUpdate = customerLogic.checkShouldUpdate || defaultCheckShouldUpdate;

    if (!issue) {
      createLogic();
    } else {
      checkShouldUpdate(context, incident, issue, function(err, shouldUpdate, noActionRequired) {
        if (err) {
          return finished(err);
        }

        if (noActionRequired) {
          return finished(null, "No action required - " + noActionRequired);
        }

        if (shouldUpdate) {
          updateLogic(issue, retryCounter);
        } else {
          createLogic();
        }
      });
    } 
  }

  function updateLogic(issue, retryCounter) {
    // This can be either for update or waiting, but in any case, update shouldn't happen if 
    // the onlyCreate flag is true
    if (config.flow.onlyCreate) { 
      console.log("No updates - Not sending call");
      return finished(null, null)
    }

    if (issue.ticket_key) {
      updateIssue(context, incident, issue, finished);
    } else {
      // Original create is underway but we need to wait till it is done before update.
      // Wait a bit and retry.
      console.log("Waiting - original request still in progress", {retry: retryCounter});
      setTimeout(() => { handleIncidentLogic(retryCounter + 1);}, RETRY_CREATE_DURATION);
    }
  }

  function createLogic() {
    var customerLogic = bpUtils.getCustomerLogic(context);

    if (customerLogic.shouldCreateIncident && !customerLogic.shouldCreateIncident(context, incident)) {
      console.log("Not creating incident - should create was false", incident);
      return finished(null, null);
    } 

    //  Flag incident to prevent multiple create
    bpUtils.storeIncidentData(context, SYSTEM, incident.id, null, null, {inProgress: true}, function(err2, data) {
      if (err2) {
        return finished(err2);
      }

      createIssue(context, incident, customerLogic, finished);
    });
  }
}

/**
 * Null pattern for the update check. 
 * Used when there is no custom logic - simply return true.
 */
function defaultCheckShouldUpdate(context, incident, issue, callback) {
  callback(null, true, null);
}

function createIssue(context, incident, customerLogic, callback) {
  console.log("Starting to create a new " + SYSTEM + " ticket for: " + incident.id);

  var reqBody = createFields(context, incident, null, CREATED_ACTION, callback);

  context.bpContext.flowLogic.createIncident(context, reqBody, incident, function(err, data) {
    if (err) {
      return callback(err, data);
    }

    return callback(null, data);
  });
}

function updateIssue(context, incident, issue, callback) {
    console.log("Starting to update a new " + SYSTEM + " ticket for: " + incident.id);

    var reqBody = createFields(context, incident, issue, UPDATED_ACTION, callback);
    reqBody.u_incident_sys_id = issue.ticket_key;

    context.bpContext.flowLogic.updateIncident(context, reqBody, incident, issue, callback);
}